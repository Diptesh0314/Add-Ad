export const environment = {
    production: false
};
  
export const baseUrl = "https://shreeya-addad-dec-2020-dev-api.azurewebsites.net/api";

