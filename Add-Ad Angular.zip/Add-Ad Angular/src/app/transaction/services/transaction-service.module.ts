import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Email } from 'src/app/models/email.model';
import { baseUrl } from 'src/environments/environment';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class TransactionServiceModule {


  

 }
