import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Email } from 'src/app/models/email.model';
import { Transaction } from 'src/app/models/transaction.model';
import { baseUrl } from '../../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  
  email: Email = new Email()
  emailId:any
  constructor( private _http : HttpClient ) { }

  getTransactions(email? : string) {
    
    return this._http.get<Transaction[]>(baseUrl+"/transaction/"+email);
  }

  paid(transaction : Transaction){
    return this._http.post<Transaction>(baseUrl+"/transaction/addtransaction",transaction)
  }

  calculateCost(transaction: Transaction) {
    return this._http.post<Transaction>(baseUrl+"/transaction/calculateCost",transaction)
  }

  sendMail(){
    this.emailId=localStorage.getItem("email")
    this.email.email=this.emailId
    console.log(this.email);
    console.log("hi");
    return this._http.post(baseUrl+'/Email/bookAd' ,this.email);
  }

}
