import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionHistoryComponent } from './components/transaction-history/transaction-history.component';
import { OrderPreviewComponent } from './components/order-preview/order-preview.component';
import { OrderSummaryComponent } from './components/order-summary/order-summary.component';
import { TransactionRoutingModule } from './transaction-routing.module';
import { SharedModule } from '../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    TransactionHistoryComponent, 
    OrderPreviewComponent, 
    OrderSummaryComponent
  ],
  imports: [
    CommonModule,
    TransactionRoutingModule,
    SharedModule,
    NgxPaginationModule
  ]
})
export class TransactionModule { }
