import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule , Routes } from '@angular/router';
import { TransactionHistoryComponent } from './components/transaction-history/transaction-history.component';
import { OrderPreviewComponent } from './components/order-preview/order-preview.component';
import { OrderSummaryComponent } from './components/order-summary/order-summary.component';
import { RoleGuardService } from '../authGuard/servies/role-guard.service';

const routes : Routes = [
  {
    path: 'transactionhistory', component : TransactionHistoryComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    } 
  },
  {
    path: 'order', component : OrderPreviewComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    } 
  },
  {
    path: 'ordersummary', component : OrderSummaryComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    } 
  },
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransactionRoutingModule { }
