import { NgbModal,ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { Transaction } from 'src/app/models/transaction.model';
import { TransactionService } from '../../services/transaction.service';
@Component({
  selector: 'app-order-preview',
  templateUrl: './order-preview.component.html',
  styleUrls: ['./order-preview.component.css']
})
export class OrderPreviewComponent implements OnInit {
  
  transaction : Transaction;
  companyName : any;
 
  constructor( private transactionService : TransactionService,
               private customerService : CustomerServiceService,
               private router : Router,public modalService:NgbModal,
               private toastr:ToastrService) { }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    if(!localStorage.getItem("transactionStatus")){
      this.router.navigate(["/customer/bookadvertisement"])
    }
    this.transaction = this.customerService.transaction;
  
    this.companyName = this.transaction.companyName;
    if(this.transaction.cost > 0)
      this.transactionService.calculateCost(this.transaction).subscribe(response => this.transaction = response);   
    
  }

  paid(){
    this.transactionService.sendMail().subscribe()
    localStorage.removeItem("transactionStatus")
    this.transactionService.paid(this.transaction).subscribe(response => { 
      this.transaction = response;
      this.toastr.success("Success","Transaction status");
    });
    
    
  }

  cancel(){
    this.router.navigate(['/customer/bookadvertisement'])
  }
  
  // open(content:any) {
  //   this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
  //     this.closeResult = `Closed with: ${result}`;
  //   }, (reason) => {
  //     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  // }
  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }

}