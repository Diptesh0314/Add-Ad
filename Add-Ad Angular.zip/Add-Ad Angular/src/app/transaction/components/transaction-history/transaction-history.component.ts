import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/core/services/login-service.service';
import { Customer } from 'src/app/models/customer.model';
import { Transaction } from 'src/app/models/transaction.model';
import { TransactionService } from '../../services/transaction.service';


@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.css']
})
export class TransactionHistoryComponent implements OnInit {

  transactions : Transaction[];
  p : number = 1;

  customer? : Customer

  constructor(private service: TransactionService,
              private loginService: LoginService, public router:Router) { }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    this.customer = this.loginService.customerDetails()
    this.getTransactions(this.customer?.emailId)
  }

  getTransactions(email? : string){
    this.service.getTransactions(email).subscribe((response) => {this.transactions = response as Transaction[]})
  }

}
