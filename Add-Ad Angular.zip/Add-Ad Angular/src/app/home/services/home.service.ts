import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {baseUrl} from '../../../environments/environment';
import { TopNewspaper } from '../models/top-newspaper.model';
import { TopTvChannel } from '../models/top-tv-channel.model';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  newspapers!: TopNewspaper[];
  tvChannels! : TopTvChannel[];

  constructor(private http: HttpClient) { }


  //To Show Top Newspaper
  showTopNewspapers(){
    this.http.get(baseUrl + '/Newspaper/ShowTopNewspapers')
    .toPromise().then(res=>this.newspapers = res as TopNewspaper[]);
  }

  //To Show Top TV Channels
  showTopTvChannels(){
      this.http.get(baseUrl + '/TvChannel/ShowTopTvChannels')
      .toPromise().then(res=>this.tvChannels = res as TopTvChannel[]);
    }
}
