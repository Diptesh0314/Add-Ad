import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { TopCustomersComponent } from './components/top-customers/top-customers.component';

const routes : Routes = [
  {
    path : '', component : HomePageComponent,
    
  },
  {
    path : 'home', component : HomePageComponent
    
  },
  {
    path : 'topcustomers', component : TopCustomersComponent
  }
]


@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]

})
export class HomeRoutingModule { }
