import { Component, OnInit } from '@angular/core';
import {HomeService } from '../../services/home.service';

@Component({
  selector: 'app-top-customers',
  templateUrl: './top-customers.component.html',
  styleUrls: ['./top-customers.component.css']
})
export class TopCustomersComponent implements OnInit {

  constructor(public service : HomeService) { }

  isTopCustomers! : boolean;
  ngOnInit(): void {
    this.isTopCustomers=true;
    this.service.showTopNewspapers();
    this.service.showTopTvChannels();
  }
}
