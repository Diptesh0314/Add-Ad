import { TopNewspaper } from './top-newspaper.model';

describe('TopNewspaper', () => {
  it('should create an instance', () => {
    expect(new TopNewspaper()).toBeTruthy();
  });
});
