export class TopTvChannel {
    userName: string;
    rating: number;
    genre: string;
    language: string;
}
