import { TopTvChannel } from './top-tv-channel.model';

describe('TopTvChannel', () => {
  it('should create an instance', () => {
    expect(new TopTvChannel()).toBeTruthy();
  });
});
