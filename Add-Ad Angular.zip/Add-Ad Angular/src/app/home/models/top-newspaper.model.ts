export class TopNewspaper {
    userName: string;
    rating: number;
    language: string;
}
