import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import {} from './home/home.module';
import {} from './core/core.module';
import {} from './shared/shared.module';
import {} from './admin/admin.module';
import {} from './customer/customer.module';
import {} from './newspaper/newspaper.module';
import {} from './televisionChannel/television-channel.module';
import {} from './transaction/transaction.module';


const routes: Routes = [
 {path: '',  redirectTo:'/home',pathMatch:'full'},
 {path: 'home',  loadChildren: () => import(`./home/home.module`).then(m => m.HomeModule)},
 {path: 'core',  loadChildren: () => import(`./core/core.module`).then(m => m.CoreModule)},
 {path: 'admin',  loadChildren: () => import(`./admin/admin.module`).then(m => m.AdminModule)},
 {path: 'customer',  loadChildren: () => import(`./customer/customer.module`).then(m => m.CustomerModule)},
 {path: 'newspaper',  loadChildren: () => import(`./newspaper/newspaper.module`).then(m => m.NewspaperModule)},
 {path: 'channel',  loadChildren: () => import(`./televisionChannel/television-channel.module`).then(m => m.TelevisionChannelModule)},
 {path: 'transaction',  loadChildren: () => import(`./transaction/transaction.module`).then(m => m.TransactionModule)},
 {path: 'shared',  loadChildren: () => import(`./shared/shared.module`).then(m => m.SharedModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
