import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Routes } from '@angular/router';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { TermsAndConditionsComponent } from './components/terms-and-conditions/terms-and-conditions.component';
import { LoginComponent } from '../core/components/login-page/login.component';


const routes : Routes = [
  { 
    path : 'aboutus', component : AboutUsComponent
  },
  { 
    path : 'termsandconditions', component : TermsAndConditionsComponent
  }
  ,{
    path:'login',component:LoginComponent
  }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class SharedRoutingModule { }
