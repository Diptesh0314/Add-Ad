import { CustomerServiceService } from './../../../customer/services/customer-service.service';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../../../core/services/login-service.service';
import { HeaderServiceService } from '../../service/header-service.service';
import { Customer } from 'src/app/models/customer.model';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  fullName:any
  name: any
  email: any
  isLogin: any
  roleVal:any;
  constructor(public loginService: LoginService,private router : Router, public headerService:HeaderServiceService) { 
    this.name=" "+this.headerService.name
    this.email= this.headerService.email
    this.isLogin=this.headerService.isLogin

  }

  isTopCustomers!:boolean;
  urlCheck !:string;
  customer?:Customer;
  user:String;

  ngOnInit(): void {
    this.fullName=localStorage.getItem("name")?.split(" ",1)
    this.name=this.fullName[0]
    this.email= localStorage.getItem("email")
    this.isLogin=this.headerService.isLogin
    this.urlCheck = this.router.url;
    this.customer=this.loginService.customerDetails();
    
    if(this.customer?.roleId==2){
      this.user="newspaper";
    }else if(this.customer?.roleId==3){
      this.user="channel";
    }
    else if(this.customer?.roleId==4){
      this.user="admin";
    }
    else if(this.customer?.roleId==1){
      this.user="customer";
    }
  }


  logout(){
    this.loginService.logout()
    
  }
}