import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HeaderServiceService {

name: string
email: string
isLogin: boolean
  constructor() { }
}
