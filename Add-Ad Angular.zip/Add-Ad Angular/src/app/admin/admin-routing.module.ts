import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Routes } from '@angular/router';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { ActiveNewsPapersComponent } from './components/active-news-papers/active-news-papers.component';
import { ActiveChannelsComponent } from './components/active-channels/active-channels.component';
import { BlockedMediumsComponent } from './components/blocked-mediums/blocked-mediums.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { AuthGuard } from '../authGuard/servies/auth-guard.service';
import { RoleGuardService } from '../authGuard/servies/role-guard.service';

const routes : Routes = [
  {
    path: 'dashboard' , 
    component : AdminDashboardComponent , 
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 4
    } 
  },
  {
    path: 'activenewspapers' , 
    component : ActiveNewsPapersComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 4
    } 
  },
  {
    path: 'activechannels' , 
    component : ActiveChannelsComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 4
    } 
  },
  {
    path: 'blockedmediums' , 
    component : BlockedMediumsComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 4
    } 
  },
  {
    path: 'pendingconfirmations' , 
    component : PendingConfirmationComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 4
    } 
  }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AdminRoutingModule { }
