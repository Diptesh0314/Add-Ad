import { BookNewspaper } from './book-newspaper';

describe('BookNewspaper', () => {
  it('should create an instance', () => {
    expect(new BookNewspaper()).toBeTruthy();
  });
});
