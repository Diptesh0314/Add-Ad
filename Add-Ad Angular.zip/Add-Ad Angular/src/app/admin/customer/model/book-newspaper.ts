export class BookNewspaper {
}
