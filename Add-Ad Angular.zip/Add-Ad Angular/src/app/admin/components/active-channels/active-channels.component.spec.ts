import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { AdminService } from '../../services/admin.service';

import { ActiveChannelsComponent } from './active-channels.component';

describe('ActiveChannelsComponent', () => {
  let component: ActiveChannelsComponent;
  let fixture: ComponentFixture<ActiveChannelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NgxPaginationModule,HttpClientTestingModule, RouterTestingModule.withRoutes(
        [{path: 'home', redirectTo: ''}])],
      declarations: [ ActiveChannelsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveChannelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should call service methods when onUpdateTvChannel is called', () => {
  //   let channel = new TvChannel;
  //   channel.cost = 100;

  //   let service = TestBed.inject(AdminService);
  //   //spyOn(service,'updateTvChannel');
  //   spyOn(service,'getActiveTvChannels').and.callFake();

  //   component.onUpdateTvChannel(channel)
  //   //expect(service.updateTvChannel).toHaveBeenCalled();
  //   expect(service.getActiveTvChannels).toHaveBeenCalled();
  //  // expect(service.getEmailTvChannel).toHaveBeenCalled();
  //  // expect(service.sendBlockMailTvChannel).toHaveBeenCalled();
  // });

});
