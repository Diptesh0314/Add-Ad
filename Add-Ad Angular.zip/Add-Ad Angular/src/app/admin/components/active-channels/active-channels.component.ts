import { Component, OnInit } from '@angular/core';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { Email } from 'src/app/models/email.model';
import { AdminService } from '../../services/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-active-channels',
  templateUrl: './active-channels.component.html',
  styleUrls: ['./active-channels.component.css'],
})
export class ActiveChannelsComponent implements OnInit {
  sendEmail: Email;
  p: number = 1;
  itemPerPage: number = 8;
  constructor(
    public serviceBook: CustomerServiceService,
    public service: AdminService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.service.getActiveTvChannels();
    if(!localStorage.getItem("token"))
        this.router.navigate(["/home"])
  }

  onUpdateTvChannel(tvChannel: TvChannel) {
    this.service.updateTvChannel(tvChannel).subscribe(
      (res) => {
        this.service.getActiveTvChannels();
        this.service.getEmailTvChannel(tvChannel).subscribe(
          (email: Email) => {
            this.service.sendBlockMailTvChannel(email).subscribe(
              (res) => {},
              (error) => {
                console.log(error);
              }
            );
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
