import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { AdminService } from '../../services/admin.service';
import { Email } from 'src/app/models/email.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-active-news-papers',
  templateUrl: './active-news-papers.component.html',
  styleUrls: ['./active-news-papers.component.css']
})
export class ActiveNewsPapersComponent implements OnInit {

  p: number = 1;
  itemPerPage: number = 8;
  constructor(public serviceBook : CustomerServiceService,
              public service:AdminService,
              public router: Router
  ) { }

  ngOnInit(): void {
    this.service.getActiveNewspaper();
    if(!localStorage.getItem("token"))
        this.router.navigate(["/home"])
  }

  onUpdateNewspaper(nw : Newspaper){
    this.service.updateNewspaper(nw).subscribe(res=>{
      this.service.getActiveNewspaper();
      this.service.getEmailNewspaper(nw).subscribe(
        (email: Email) => {
          this.service.sendBlockMailNewspaper(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }
}
