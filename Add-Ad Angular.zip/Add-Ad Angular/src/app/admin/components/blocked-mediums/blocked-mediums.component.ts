import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Email } from 'src/app/models/email.model';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-blocked-mediums',
  templateUrl: './blocked-mediums.component.html',
  styleUrls: ['./blocked-mediums.component.css']
})
export class BlockedMediumsComponent implements OnInit {

  p : number =1;
  q : number =1;
  itemsPerPageChannel:number=8;
  itemPerPageNewspaper:number=8;

  constructor(public service : AdminService,
              public router : Router) { }

  ngOnInit(): void {
    
    this.service.blockedNewspapers();
    this.service.blockedTvChannels();
    if(!localStorage.getItem("token"))
        this.router.navigate(["/home"])
  }

  unblockTvChannel(tvChannel : TvChannel){
    this.service.unblockTvChannel(tvChannel).subscribe(res=>{
      this.service.blockedTvChannels();
      this.service.getEmailTvChannel(tvChannel).subscribe(
        (email: Email) => {
          this.service.sendUnblockMailTvChannel(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }

  unblockNewspaper(newsaper  :Newspaper){
    this.service.unblockNewspaper(newsaper).subscribe(res=>{
      this.service.blockedNewspapers();
      this.service.getEmailNewspaper(newsaper).subscribe(
        (email: Email) => {
          this.service.sendUnblockMailNewspaper(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }

}
