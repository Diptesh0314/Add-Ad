import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Email } from 'src/app/models/email.model';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-pending-confirmation',
  templateUrl: './pending-confirmation.component.html',
  styleUrls: ['./pending-confirmation.component.css']
})
export class PendingConfirmationComponent implements OnInit {

  p: number = 1;
  q:number = 1;
  itemsPerPageChannel:number=8;
  itemPerPageNewspaper:number=8;
  constructor(public service: AdminService,
              public router: Router) { }

  ngOnInit(): void {
    this.service.notApprovedNewspapers();
    this.service.notApprovedTvChannels();
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    }
  }

  approveNewspaper(newspaper : Newspaper){
    this.service.approveNewspaper(newspaper).subscribe(res=>{
      this.service.notApprovedNewspapers();
      this.service.getEmailNewspaper(newspaper).subscribe(
        (email: Email) => {
          this.service.sendApproveEmailNewspaper(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }

  approveTvChannel(tvChannel : TvChannel){
    this.service.approveTvChannel(tvChannel).subscribe(res=>{
      this.service.notApprovedTvChannels();
      this.service.getEmailTvChannel(tvChannel).subscribe(
        (email: Email) => {
          this.service.sendApproveEmailTvChannel(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }

  rejectNewspaper(newspaper : Newspaper){
    this.service.rejectNewspaper(newspaper).subscribe(res=>{
      this.service.notApprovedNewspapers();
      this.service.getEmailNewspaper(newspaper).subscribe(
        (email: Email) => {
          this.service.sendRejectEmailNewspaper(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }

  rejectTvChannel(tvChannel : TvChannel){
    this.service.rejectTvChannel(tvChannel).subscribe(res=>{
      this.service.notApprovedTvChannels();
      this.service.getEmailTvChannel(tvChannel).subscribe(
        (email: Email) => {
          this.service.sendRejectEmailTvChannel(email).subscribe(
            (res) => {},
            (error) => {
              console.log(error);
            }
          );
        },
        (err) => {
          console.log(err);
        }
      );
    },err=>{console.log(err);})
  }
  
}
