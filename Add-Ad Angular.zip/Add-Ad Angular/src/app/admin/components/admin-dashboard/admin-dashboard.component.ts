import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/core/services/login-service.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor(public loginService:LoginService,private router:Router) { }

  ngOnInit(): void {
    if(this.loginService.customer.roleId!=4)
      this.router.navigate(['/home']);

    if(!localStorage.getItem("token")){
        this.router.navigate(["/home"])
    }
  }
}
