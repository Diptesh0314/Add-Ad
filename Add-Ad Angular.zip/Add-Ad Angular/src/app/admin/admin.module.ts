import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ActiveChannelsComponent } from './components/active-channels/active-channels.component';
import { ActiveNewsPapersComponent } from './components/active-news-papers/active-news-papers.component';
import { BlockedMediumsComponent } from './components/blocked-mediums/blocked-mediums.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';



@NgModule({
  declarations: [AdminDashboardComponent, ActiveChannelsComponent, ActiveNewsPapersComponent, BlockedMediumsComponent, PendingConfirmationComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
    NgxPaginationModule
  ]
})
export class AdminModule { }
