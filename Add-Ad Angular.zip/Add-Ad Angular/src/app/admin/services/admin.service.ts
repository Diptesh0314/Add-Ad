import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Email } from 'src/app/models/email.model';
import {baseUrl} from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  blockedNewspaperList : Newspaper[];
  notApprovedNewspapersList:Newspaper[];
  blockedTvChannelsList:TvChannel[];
  notApprovedTvChannelsList:TvChannel[];
  emailTvChannel : string;
  emailNewspaper :string;
  tvChannelId? : Number;
  activeTvChannels:TvChannel[];
  activeNewspaper:Newspaper[];
  constructor(public http:HttpClient) { }

  approveTvChannel(channel:TvChannel){
    return this.http.put(baseUrl+"/TvChannel/ApproveTvChannel/",channel);
  }

  approveNewspaper(newspaper: Newspaper){
    return this.http.put(baseUrl+"/Newspaper/ApproveNewspaper/",newspaper);
  }

  rejectTvChannel(channel:TvChannel){
    return this.http.put(baseUrl+"/TvChannel/RejectTvChannel/",channel);
  }

  rejectNewspaper(newspaper: Newspaper){
    return this.http.put(baseUrl+"/Newspaper/rejectNewspaper/",newspaper);
  }
  updateNewspaper(nw : Newspaper){
    return this.http.put(baseUrl+"/Newspaper/UpdateNewspaper/",nw);
  }

  updateTvChannel(channel : TvChannel){
    return this.http.put(baseUrl+"/TvChannel/UpdateTvChannel",channel);
  }

  unblockTvChannel(tvChannel : TvChannel){
      return this.http.put(baseUrl+"/TvChannel/UnblockTvChannel/",tvChannel);
  }

  unblockNewspaper(newspaper:Newspaper){
    return this.http.put(baseUrl+"/Newspaper/UnblockNewspaper/",newspaper)
  }

  blockedNewspapers(){
    this.http.get(baseUrl + '/Newspaper/GetBlockedNewspapers')
    .toPromise()
    .then(res => this.blockedNewspaperList = res as Newspaper[])
  }

  getActiveTvChannels(){
    this.http.get(baseUrl+'/TvChannel/GetActiveTvChannel').toPromise().then(res=>this.activeTvChannels=res as TvChannel[])
  }

  getActiveNewspaper(){
    this.http.get(baseUrl+'/Newspaper/GetActiveNewspaper').toPromise().then(res=>this.activeNewspaper=res as Newspaper[])
  }
  blockedTvChannels(){
    this.http.get(baseUrl + '/TvChannel/GetBlockedTvChannels')
    .toPromise()
    .then(res => this.blockedTvChannelsList = res as TvChannel[])
  }

  notApprovedNewspapers(){
    this.http.get(baseUrl + '/Newspaper/GetNotApprovedNewspapers')
    .toPromise()
    .then(res => this.notApprovedNewspapersList = res as Newspaper[])
  }

  notApprovedTvChannels(){
    this.http.get(baseUrl + '/TvChannel/GetNotApprovedTvChannels')
    .toPromise()
    .then(res => this.notApprovedTvChannelsList = res as TvChannel[])
  }

  //Get Email of TvChannel and Newspaper by Id
  getEmailNewspaper(newspaper : Newspaper){
    return this.http.post<Email>(baseUrl+"/Newspaper/GetEmailNewspaper",newspaper);
  }
  getEmailTvChannel(tvChannel:TvChannel){
    return this.http.post<Email>(baseUrl+"/TvChannel/GetEmailTvChannel",tvChannel);
  }


  //Blocking Mail to TvChannel and Newspaper
  sendBlockMailNewspaper(email : Email){
    return this.http.post(baseUrl+'/Email/SendBlockEmailNewspaper',email);
  }
  sendBlockMailTvChannel(email:Email){
    return this.http.post(baseUrl+'/Email/SendBlockEmailTvChannel',email);
  }

  //UnBlock Mail to TvChannel and Newspaper Channel
  sendUnblockMailNewspaper(email:Email){
    return this.http.post(baseUrl+'/Email/SendUnblockEmailNewspaper',email);
  }

  sendUnblockMailTvChannel(email:Email){
      return this.http.post(baseUrl+'/Email/SendUnblockEmailTvChannel',email);
  }

  //Approve Mail to TvChannel and NewspaperServiceModule
  sendApproveEmailTvChannel(email : Email){
    return this.http.post(baseUrl+'/Email/SendApproveEmailTvChannel',email);
  }

  sendApproveEmailNewspaper(email:Email){
    return this.http.post(baseUrl+'/Email/SendApproveEmailNewspaper',email);
  }

  //Reject Mail to TvChannel and Newspaper
  sendRejectEmailTvChannel(email : Email){
    return this.http.post(baseUrl+'/Email/SendRejectEmailTvChannel',email);
  }

  sendRejectEmailNewspaper(email :Email){
    return this.http.post(baseUrl+'/Email/SendRejectEmailNewspaper',email);
  }
}
