import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import { LoginService } from 'src/app/core/services/login-service.service';
import { Customer } from 'src/app/models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class RoleGuardService implements CanActivate {
  customer?:Customer=new Customer(); 
  constructor(public loginService:LoginService,public router:Router) { 
     this.customer=this.loginService.customerDetails();
  }
  canActivate(route: ActivatedRouteSnapshot): boolean {
    
    const expectedRole = route.data.expectedRole;
    const tokenRole = this.customer?.roleId;
    if (
      tokenRole !== expectedRole
    ) {
      this.router.navigate(['/home']);
      return false;
    }
    return true;
  }
}
