export class TvChannel {
    tvChannelId?:number;
    userName!:string;
    customerUserId?:Number;
    genre?:string;
    language?:string;
    cost?:number;
    rating!:number;
}
