import { Newspaper } from './newspaper.model';

describe('Newspaper', () => {
  it('should create an instance', () => {
    expect(new Newspaper()).toBeTruthy();
  });
});
