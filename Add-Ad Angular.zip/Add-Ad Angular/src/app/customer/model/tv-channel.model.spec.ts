import { TvChannel } from './tv-channel.model';

describe('TvChannel', () => {
  it('should create an instance', () => {
    expect(new TvChannel()).toBeTruthy();
  });
});
