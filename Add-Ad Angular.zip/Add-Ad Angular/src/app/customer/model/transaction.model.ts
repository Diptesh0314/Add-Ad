import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Newspaper } from 'src/app/models/newspaper.model';
export class Transaction{
    transactionId?:number
    tvChannelId:number
    newspaperId:number
    userName:string
    customerUserId:number
    cost:number
    isApproved:number
    adSizeInPaper:number
    adDurationInPaper:number
    numberOfDays!:Number;
    pageNumber!: Number;
    


}