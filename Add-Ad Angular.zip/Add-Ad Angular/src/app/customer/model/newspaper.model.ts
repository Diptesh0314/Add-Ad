export class Newspaper {
   newsPaperId?:number;
    userName!: string;
    customerUserId?:Number;
    language?:string;
    cost?:number;
    rating!:number;
}
