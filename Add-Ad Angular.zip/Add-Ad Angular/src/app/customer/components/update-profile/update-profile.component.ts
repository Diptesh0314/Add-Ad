import { CustomerServiceService } from './../../services/customer-service.service';
import { Customer } from 'src/app/models/customer.model';
import { LoginService } from './../../../core/services/login-service.service';
import { LoginModel } from 'src/app/models/loginModel';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MustMatch } from 'src/app/shared/validators/must-match.validator';


@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  
  public resetPasswordForm: FormGroup;
  public showSuccess: boolean;
  public showError: boolean;
  public errorMessage: string;
  public email:any;
  public name: any;
  public customer :Customer
  roleType:Number
  public loginmodel: LoginModel = new LoginModel
  constructor( public router:Router,public route:ActivatedRoute, private ad: FormBuilder,public loginService: LoginService, public customerService: CustomerServiceService) { }
  form = this.ad.group({
    email: new FormControl('', [Validators.email , Validators.required , this.validator]),
    current_password: new FormControl('', [Validators.required, Validators.minLength(1), Validators.maxLength(20)]),
    confirm_password: new FormControl('', [Validators.required, Validators.minLength(1), Validators.maxLength(20)]),

    password: new FormControl('', [Validators.required, Validators.minLength(1), Validators.maxLength(20),Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]),
  },
  {
    validator: MustMatch('password', 'confirm_password')
})
  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    this.roleType=this.loginService.customer.roleId;
    this.name=localStorage.getItem("name")
    this.email= localStorage.getItem("email")
  }
  validator(control : AbstractControl) : ValidationErrors | null{
    let char = (control.value as string)
    let regexp = new RegExp('[a-zA-Z]')
    if(!regexp.test(char[0]))
      return { validator : true }
      
    return null
  }
  logout(){
    this.loginService.logout()
  }
  login(){
    this.loginmodel.emailid = this.email
    this.loginmodel.password = this.form.controls.current_password.value
   // this.loginService.logout()
    this.loginService.login(this.loginmodel).subscribe(response => {
      if(response){
        this.customer = response
        
      if(this.form.controls.password.value==this.form.controls.current_password.value)
      {
        this.errorMessage="current and new password cant be same"
      }
      else if(this.form.controls.password.value!=this.form.controls.confirm_password.value)
      {
        this.errorMessage="password and confirm password dos not matched"
      }
      else
      {
        this.customer.password=this.form.controls.password.value;
        this.customerService.updateCustomer(this.customer).subscribe(
          err=>{console.log(err);}
        );
        alert("updated successfully")
        if(this.roleType==1)
        this.router.navigate(['customer/bookadvertisement'],{queryParams:{data:this.customer.userName,data2:this.customer.emailId}})
        if(this.roleType==2)
        this.router.navigate(['newspaper/dashboard'])
        if(this.roleType==3)
        this.router.navigate(['channel/dashboard']);
        if(this.roleType==4)
        this.router.navigate(['admin/dashboard']);

      }}
    },error => {
      this.errorMessage ="invalid current password"
    })
  }
  
}
