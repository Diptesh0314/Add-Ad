import { By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';

import { UpdateProfileComponent } from './update-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UpdateProfileComponent', () => {
  let component: UpdateProfileComponent;
  let fixture: ComponentFixture<UpdateProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateProfileComponent ],
      imports: [HttpClientTestingModule, ReactiveFormsModule,RouterTestingModule.withRoutes(
        [{path: 'home', redirectTo: ''}]
      )]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('form should be valid', () => {

    component.form.get("email")?.setValue("bhimeshp14@gmail.com")
    component.form.get("password")?.setValue("Bhim@123")
    component.form.get("confirm_password")?.setValue("Bhim@123")
    component.form.get("current_password")?.setValue("Bhim@456")
    expect(component.form.valid).toBeTruthy();

})
it('form should be invalid', () => {

  component.form.get("email")?.setValue("")
  component.form.get("password")?.setValue("")
  component.form.get("confirm_password")?.setValue("")
  component.form.get("current_password")?.setValue("")
  expect(component.form.valid).toBeFalsy();

})

it('should call update method when button is clicked', () => {

  spyOn(component,'login');
  let button = fixture.debugElement.query(By.css("form"));
  button.triggerEventHandler('submit',null);
  fixture.detectChanges();
  expect(component.login).toHaveBeenCalled();

})
  it('should login after giving credentials', () => {
    component.form.get("email")?.setValue("bhimeshp14@gmail.com")
    component.form.get("password")?.setValue("123")
    component.form.get("confirm_password")?.setValue("123")
    component.form.get("current_password")?.setValue("123")
    expect("123").toBe(component.form.get('password')?.value)
    expect("bhimeshp14@gmail.com").toBe(component.form.get('email')?.value)
    expect("123").toBe(component.form.get('confirm_password')?.value)
    expect("123").toBe(component.form.get('current_password')?.value)
  });
});
