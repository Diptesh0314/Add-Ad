import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { LoginService } from './../../../core/services/login-service.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
//import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-book-for-newspaper',
  templateUrl: './book-for-newspaper.component.html',
  styleUrls: ['./book-for-newspaper.component.css']
})
export class BookForNewspaperComponent implements OnInit {
  cost:any
  id:any
  name:any
  BookForm:FormGroup
  date:Date
  outDate:string
  maxDate:string
  NewsPaperName:any
  constructor(public router: Router,private ad: FormBuilder, public route: ActivatedRoute,public loginService: LoginService, public service:CustomerServiceService) { 
    this.date  = new Date()
    let month = String(this.date.getMonth() + 1).padStart(2, '0'); 
    let day = String(this.date.getDate()+2).padStart(2, '0'); 
    let year = this.date.getFullYear(); 
    let yearMax = this.date.getFullYear()+1;
    this.outDate = year +'-'+month +'-'+day 
    this.maxDate=yearMax+'-'+month+'-'+day

  }
  
  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    if(!(localStorage.getItem("transactionStatus"))){
      this.router.navigate(["/customer/bookadvertisement"])
    }
    this.cost=localStorage.getItem("NewspaperCost")
    this.NewsPaperName=localStorage.getItem("NewsPaperName")
    this.BookForm = this.ad.group({
      cost: [''],
      size: ['',[ Validators.required,Validators.min(5), Validators.max(25)]],
      page:['',[Validators.required, Validators.min(1), Validators.max(24)]],
      date : ['',[Validators.required]],
      days : ['',[Validators.required, Validators.min(1), Validators.max(365)]]
      })
  
   }
  book(){

    this.service.transaction.newspaperId=Number(localStorage.getItem("NewspaperId"))
    this.service.transaction.tvChannelId=0;
    this.service.transaction.cost=Number(localStorage.getItem("NewspaperCost"))
    this.service.transaction.isApproved = 0
    this.service.transaction.adSizeInPaper=this.BookForm.controls.size.value;
    this.service.transaction.numberOfDays =this.BookForm.controls.days.value;
    this.service.transaction.pageNumber = this.BookForm.controls.page.value;
    this.service.transaction.serviceDate= this.BookForm.controls.date.value;
    this.service.transaction.transactionDate = new Date();
    this.service.transaction.companyName = this.NewsPaperName;

    if(this.service.transaction.serviceDate < this.date)
    {
      console.log("hello")
    }
    //this.service.transaction.

    this.name=localStorage.getItem("name")
    

    this.service.GetUserId(this.name).subscribe((response)=>{
      this.id=response
      this.service.transaction.customerUserId=this.id
    })

    this.router.navigate(["/transaction/order"]);
  }

  disableDate(){ 
    return false; 
}

}
