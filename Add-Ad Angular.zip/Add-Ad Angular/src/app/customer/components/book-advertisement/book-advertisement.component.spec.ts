import { from } from 'rxjs';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { By } from '@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { BookAdvertisementComponent } from './book-advertisement.component';
import { hasClassName } from '@ng-bootstrap/ng-bootstrap/util/util';
import { hostViewClassName } from '@angular/compiler';

describe('BookAdvertisementComponent', () => {
  let component: BookAdvertisementComponent;
  let fixture: ComponentFixture<BookAdvertisementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes(
        [{path: 'home', redirectTo: ''}]
      )],
      declarations: [ BookAdvertisementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookAdvertisementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call search method when button is clicked', () => {

    spyOn(component,'searchData');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('button')?.click()
    fixture.detectChanges();
    expect(component.searchData).toHaveBeenCalled();
  
  
  })

  it('should call checknews method when news check is clicked', () => {

    spyOn(component,'checkNews');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('newscheck')?.click()
    fixture.detectChanges();
    expect(component.checkNews).toHaveBeenCalled();
  
  
  })

  it('should call checkChannel method when channel check is clicked', () => {

    spyOn(component,'checkChannel');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('channelcheck')?.click()
    fixture.detectChanges();
    expect(component.checkChannel).toHaveBeenCalled();
  
  
  })
  it('should call checkRating1 method when rating 1 check is clicked', () => {

    spyOn(component,'checkRating1');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('rating1')?.click()
    fixture.detectChanges();
    expect(component.checkRating1).toHaveBeenCalled();
  
  
  })
  it('should call checkRating2 method when rating 2 check is clicked', () => {

    spyOn(component,'checkRating2');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('rating2')?.click()
    fixture.detectChanges();
    expect(component.checkRating2).toHaveBeenCalled();
  
  
  })
  it('should call checkRating3 method when rating 3 check is clicked', () => {

    spyOn(component,'checkRating3');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('rating3')?.click()
    fixture.detectChanges();
    expect(component.checkRating3).toHaveBeenCalled();
  
  
  })
  it('should call checkRating4 method when rating 4 check is clicked', () => {

    spyOn(component,'checkRating4');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('rating4')?.click()
    fixture.detectChanges();
    expect(component.checkRating4).toHaveBeenCalled();
  
  
  })
  it('should call checkRating1 method when rating 1 check is clicked', () => {

    spyOn(component,'checkRating5');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('rating5')?.click()
    fixture.detectChanges();
    expect(component.checkRating5).toHaveBeenCalled();
  
  
  })
  it('should call BookNews method when BookNews button is clicked', () => {

    spyOn(component,'BookNewsPaper');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('BookNews')?.click()
    fixture.detectChanges();
 //   expect(component.BookNewsPaper).toHaveBeenCalled();
  })
  it('should call BookNews method when BookNewsLang button is clicked', () => {

    spyOn(component,'BookNewsPaper');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('BookNewsLang')?.click()
    fixture.detectChanges();
 //   expect(component.BookNewsPaper).toHaveBeenCalled();
  })
  it('should call BookNews method when BookNewsSearch button is clicked', () => {

    spyOn(component,'BookNewsPaper');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('BookNewsSearch')?.click()
    fixture.detectChanges();
 //   expect(component.BookNewsPaper).toHaveBeenCalled();
  })
  it('should call BookChannel method when BookChannelLang button is clicked', () => {

    spyOn(component,'BookNewsPaper');
    fixture.detectChanges();
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
    document.getElementById('BookChannelLang')?.click()
    fixture.detectChanges();
 //   expect(component.BookNewsPaper).toHaveBeenCalled();
  })
  it('should call BookChannel method when BookChannel button is clicked', () => {

    spyOn(component,'BookChannel');
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
   // expect(document.getElementById('BookChannel')).toBeTruthy();
    document.getElementById('BookChannel')?.click();
    fixture.detectChanges();
    //expect(component.BookChannel).toHaveBeenCalled();
  })
  it('should call BookChannel method when BookChannelGenre button is clicked', () => {

    spyOn(component,'BookChannel');
    // let button = fixture.nativeElement.querySelector(By.css('#button')); // modify here
    // button.click();
   // expect(document.getElementById('BookChannel')).toBeTruthy();
    document.getElementById('BookChannelGenre')?.click();
    fixture.detectChanges();
    //expect(component.BookChannel).toHaveBeenCalled();
  })

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call rating in customer service class for check rating 2',() => {
    let list:Newspaper[]=[]
    let newspaper=new Newspaper();
    newspaper.cost=10
    newspaper.customerUserId=2
    newspaper.language="hindi"
    newspaper.newsPaperId=1
    newspaper.rating=2
    newspaper.userName="Aajtak"
    list.push(newspaper)

    let service = TestBed.inject(CustomerServiceService); 
    spyOn(service,'searchNewspaperRating').and.returnValue(from([list]));
    document.getElementById('rating2')?.click();
    fixture.detectChanges();
    component.checkRating2(document.getElementById('rating2'))
    expect(component.n).toBe(list)
    

  });
  it('should call rating in customer service class for check rating 3',() => {
    let list:Newspaper[]=[]
    let newspaper=new Newspaper();
    newspaper.cost=10
    newspaper.customerUserId=2
    newspaper.language="hindi"
    newspaper.newsPaperId=1
    newspaper.rating=3
    newspaper.userName="Aajtak"
    list.push(newspaper)

    let service = TestBed.inject(CustomerServiceService); 
    spyOn(service,'searchNewspaperRating').and.returnValue(from([list]));
    document.getElementById('rating3')?.click();
    fixture.detectChanges();
    component.checkRating3(document.getElementById('rating3'))
    expect(component.n).toBe(list)
    

  });
  it('should call rating in customer service class for check rating 4',() => {
    let list:Newspaper[]=[]
    let newspaper=new Newspaper();
    newspaper.cost=10
    newspaper.customerUserId=2
    newspaper.language="hindi"
    newspaper.newsPaperId=1
    newspaper.rating=4
    newspaper.userName="Aajtak"
    list.push(newspaper)

    let service = TestBed.inject(CustomerServiceService); 
    spyOn(service,'searchNewspaperRating').and.returnValue(from([list]));
    document.getElementById('rating4')?.click();
    fixture.detectChanges();
    component.checkRating4(document.getElementById('rating4'))
    expect(component.n).toBe(list)
    

  });
  it('should call rating in customer service class for check rating 5',() => {
    let list:Newspaper[]=[]
    let newspaper=new Newspaper();
    newspaper.cost=10
    newspaper.customerUserId=2
    newspaper.language="hindi"
    newspaper.newsPaperId=1
    newspaper.rating=5
    newspaper.userName="Aajtak"
    list.push(newspaper)

    let service = TestBed.inject(CustomerServiceService); 
    spyOn(service,'searchNewspaperRating').and.returnValue(from([list]));
    document.getElementById('rating5')?.click();
    fixture.detectChanges();
    component.checkRating5(document.getElementById('rating5'))
    expect(component.n).toBe(list)
    

  });
  it('should call rating in customer service class for check rating 1',() => {
    let list:Newspaper[]=[]
    let newspaper=new Newspaper();
    newspaper.cost=10
    newspaper.customerUserId=2
    newspaper.language="hindi"
    newspaper.newsPaperId=1
    newspaper.rating=1
    newspaper.userName="Aajtak"
    list.push(newspaper)

    let service = TestBed.inject(CustomerServiceService); 
    spyOn(service,'searchNewspaperRating').and.returnValue(from([list]));
    document.getElementById('rating1')?.click();
    fixture.detectChanges();
    component.checkRating1(document.getElementById('rating1')?.click())
    expect(component.n).toBe(list)
    

  });
});
