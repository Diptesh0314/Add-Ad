import { Console } from 'node:console';
import { Newspaper } from './../../model/newspaper.model';
import { TvChannel } from './../../model/tv-channel.model';
import { CustomerServiceService } from './../../services/customer-service.service';
import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../../core/services/login-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AttachSession } from 'protractor/built/driverProviders';
import { SSL_OP_CRYPTOPRO_TLSEXT_BUG } from 'constants';
import { NgbCalendarHijri } from '@ng-bootstrap/ng-bootstrap/datepicker/hijri/ngb-calendar-hijri';
import { summaryForJitName } from '@angular/compiler/src/aot/util';
import { off } from 'node:process';

@Component({
  selector: 'app-book-advertisement',
  templateUrl: './book-advertisement.component.html',
  styleUrls: ['./book-advertisement.component.css']
})
export class BookAdvertisementComponent implements OnInit {
  showGenreRating: boolean;
  showLang: boolean;
  isNews: boolean;

  constructor(public service: CustomerServiceService, public loginService: LoginService, public router: Router, public route: ActivatedRoute) {
    this.displayNews = true;
    this.displayChannel = true;
    this.sort = false;
    this.rating = false;
    this.rating5=false
    this.rating4=false
    this.rating3=false
    this.rating2=false
    this.rating1=false
    this.error = false;
    this.showLang=false;
    this.searchNews = false;
    this.channelNotPresent = false;
    this.newsNotPresent = false;
    this.service.newspaperList().subscribe((response) => {
      this.allNewsPaper=response;
      this.n=this.allNewsPaper;
      
      
    });
    this.service.channelList().subscribe((response) => {
      this.allTvChannel=response;
      this.c=this.allTvChannel;
      
      
    });

  }
  rating1:boolean
  rating2:boolean
  rating3:boolean
  rating4:boolean
  rating5:boolean
  name: string
  genre: string
  lCount:number=0
  beforeChannelLangFilter:TvChannel[]
  beforeNewspaperLangFilter:Newspaper[]
  k:Newspaper[]
  q:Newspaper[]
  langChannelFilter:TvChannel[]
  langNewspaperFilter:Newspaper[]
  l:TvChannel[]
  m:TvChannel[]
  language:string
  count:number=0
  newsNotPresent: boolean
  channelNotPresent: boolean
  email: string
  channelBeforeSort:TvChannel[]
  newsBeforeSort:Newspaper[]
  genreChannel: TvChannel[]
  channel?: TvChannel[]
  searchNews?: boolean
  displayNews?: boolean
  rating: boolean
  error: boolean
  value: any
  langChannel:TvChannel[]
  langNewspaper:Newspaper[]
  showGenreWithRating: boolean
  displayChannel?: boolean
  newspaper!: Newspaper[]
  allNewsPaper:Newspaper[]
  allTvChannel:TvChannel[]
  n:Newspaper[]
  c:TvChannel[]
  check: boolean
  isChannel: boolean
  channelRating: boolean
  newsRating: boolean
  showGenre: boolean
  displayGenre: boolean
  sort: boolean

  ngOnInit(): void {
    if(!localStorage.getItem("token")){

      this.router.navigate(["/home"])
    
    }
    
    //localStorage.removeItem("transactionStatus")

  }

  logout() {
    this.loginService.logout()
  }

  searchData(item: any) {
    this.displayGenre = true;

    if (item.value == "") {
      location.reload()
    }
    else {
      this.newsRating = false
      this.channelRating = false
      this.check = false
      this.displayNews = false;
      this.displayChannel = false;
      this.service.searchNewsPaper(item.value).subscribe((response) => {
        this.channel = response;
        if (this.channel[0].genre == "Kids" || this.channel[0].genre == "News" || this.channel[0].genre == "Sports" || this.channel[0].genre == "Music"
          || this.channel[0].genre == "Movies") {
          console.log("channel")
          this.isNews=false
          this.isChannel = true
        }
        else {
          this.isChannel = false
          this.isNews=true
          console.log("Newspaper")
        }
        if (response[0] != null) {
          this.error = false
          this.searchNews = true;
          this.newsNotPresent = false;

        }

      }, error => {
        console.log("inside news error")
        this.newsNotPresent = true;
        this.searchNews = false;
        this.error = true;
      })


    }

  }

  checkNews(e: any) {
    if (e.target.checked == true) {
      this.displayNews=true
      
    }
    else {
      this.displayNews=false
     
    }
  }
  checkChannel(e: any) {
    if (e.target.checked == true) {

      this.displayChannel=true

    }
    else {
      this.displayChannel = false;
      }

  }


  checkRating1(item?: any) {
    console.log(this.n)
    let r:boolean=false
    if (item.target.checked == true){
      this.rating1=true
      if(this.count>0){
        this.count++;
        
      this.k=this.n
      this.l=this.c
      for(var i=0;i<this.allNewsPaper.length;i++)
      {
        if(this.allNewsPaper[i].rating==1)
        {
          this.k.push(this.allNewsPaper[i])
        }
      }
      this.n=this.k;
      this.k=[]
      for(var i=0;i<this.allTvChannel.length;i++)
      {
        if(this.allTvChannel[i].rating==1)
        {
          this.l.push(this.allTvChannel[i])
        }
      }
      this.c=this.l;
      this.l=[]

    }
    else
    {
        this.count++
        r=true
        this.k=[]
        for(var i=0;i<this.allNewsPaper.length;i++)
        {
          if(this.allNewsPaper[i].rating==1)
          {
            this.k.push(this.allNewsPaper[i])
          }
        }
        this.n=this.k;
        this.k=[]
        this.l=[]
        for(var i=0;i<this.allTvChannel.length;i++)
        {
          if(this.allTvChannel[i].rating==1)
          {
            this.l.push(this.allTvChannel[i])
          }
        }
        this.c=this.l;
        this.l=[]

    }
    

    }
    else{
      this.rating1=false
      if(this.count>1)
      { this.count--;
        this.q=[]
        for(var i =0;i<this.n.length;i++)
        {
          if(this.n[i].rating!=1)
          {
            this.q.push(this.n[i])
          }
        }
        this.n=this.q;
        this.q=[]
        this.m=[]
        for(var i =0;i<this.c.length;i++)
        {
          if(this.c[i].rating!=1)
          {
            this.m.push(this.c[i])
          }
        }
        this.c=this.m;
        this.m=[]
      }
      else
      { this.count--;
        if(this.showLang==false){
          this.n=this.allNewsPaper;
          this.c=this.allTvChannel}
          else{
            this.n=[]
            this.c=[]
          }
      }
    }


  }
  checkRating2(item?: any) {
    if (item.target.checked == true){
      this.rating2=true
      if(this.count>0){
        this.count++;
        
      this.k=this.n
      this.l=this.c
      for(var i=0;i<this.allNewsPaper.length;i++)
      {
        if(this.allNewsPaper[i].rating==2)
        {
          this.k.push(this.allNewsPaper[i])
        }
      }
      this.n=this.k;
      this.k=[]
      for(var i=0;i<this.allTvChannel.length;i++)
      {
        if(this.allTvChannel[i].rating==2)
        {
          this.l.push(this.allTvChannel[i])
        }
      }
      this.c=this.l;
      this.l=[]

    }
    else
    {
        this.count++
        
        this.k=[]
        for(var i=0;i<this.allNewsPaper.length;i++)
        {
          if(this.allNewsPaper[i].rating==2)
          {
            this.k.push(this.allNewsPaper[i])
          }
        }
        this.n=this.k;
        this.k=[]
        this.l=[]
        for(var i=0;i<this.allTvChannel.length;i++)
        {
          if(this.allTvChannel[i].rating==2)
          {
            this.l.push(this.allTvChannel[i])
          }
        }
        this.c=this.l;
        this.l=[]

    }

    }
    else{
      this.rating2=false
      if(this.count>1)
      { this.count--;
        this.q=[]
        for(var i =0;i<this.n.length;i++)
        {
          if(this.n[i].rating!=2)
          {
            this.q.push(this.n[i])
          }
        }
        this.n=this.q;
        this.q=[]
        this.m=[]
        for(var i =0;i<this.c.length;i++)
        {
          if(this.c[i].rating!=2)
          {
            this.m.push(this.c[i])
          }
        }
        this.c=this.m;
        this.m=[]
      }
      else
      { this.count--;
        if(this.showLang==false){
          this.n=this.allNewsPaper;
          this.c=this.allTvChannel}
          else{
            this.n=[]
            this.c=[]
          }
      }
    }

  }
  checkRating3(item: any) {

    if (item.target.checked == true){
      this.rating3=true
      if(this.count>0){
        this.count++;
        
      this.k=this.n
      this.l=this.c
      for(var i=0;i<this.allNewsPaper.length;i++)
      {
        if(this.allNewsPaper[i].rating==3)
        {
          this.k.push(this.allNewsPaper[i])
        }
      }
      this.n=this.k;
      this.k=[]
      for(var i=0;i<this.allTvChannel.length;i++)
      {
        if(this.allTvChannel[i].rating==3)
        {
          this.l.push(this.allTvChannel[i])
        }
      }
      this.c=this.l;
      this.l=[]

    }
    else
    {
        this.count++
        this.k=[]
        for(var i=0;i<this.allNewsPaper.length;i++)
        {
          if(this.allNewsPaper[i].rating==3)
          {
            this.k.push(this.allNewsPaper[i])
          }
        }
        this.n=this.k;
        this.k=[]
        this.l=[]
        for(var i=0;i<this.allTvChannel.length;i++)
        {
          if(this.allTvChannel[i].rating==3)
          {
            this.l.push(this.allTvChannel[i])
          }
        }
        this.c=this.l;
        this.l=[]

    }

    }
    else{
      this.rating3=false
      if(this.count>1)
      { this.count--;
        this.q=[]
        for(var i =0;i<this.n.length;i++)
        {
          if(this.n[i].rating!=3)
          {
            this.q.push(this.n[i])
          }
        }
        this.n=this.q;
        this.q=[]
        this.m=[]
        for(var i =0;i<this.c.length;i++)
        {
          if(this.c[i].rating!=3)
          {
            this.m.push(this.c[i])
          }
        }
        this.c=this.m;
        this.m=[]
      }
      else
      { this.count--;
        if(this.showLang==false){
          this.n=this.allNewsPaper;
          this.c=this.allTvChannel}
          else{
            this.n=[]
            this.c=[]
          }
      }
    }

  }
  checkRating4(item: any) {

    if (item.target.checked == true){
      this.rating4=true
      if(this.count>0){
        this.count++;
        
      this.k=this.n
      this.l=this.c
      for(var i=0;i<this.allNewsPaper.length;i++)
      {
        if(this.allNewsPaper[i].rating==4)
        {
          this.k.push(this.allNewsPaper[i])
        }
      }
      this.n=this.k;
      this.k=[]
      for(var i=0;i<this.allTvChannel.length;i++)
      {
        if(this.allTvChannel[i].rating==4)
        {
          this.l.push(this.allTvChannel[i])
        }
      }
      this.c=this.l;
      this.l=[]

    }
    else
    {
        this.count++
        this.k=[]
        for(var i=0;i<this.allNewsPaper.length;i++)
        {
          if(this.allNewsPaper[i].rating==4)
          {
            this.k.push(this.allNewsPaper[i])
          }
        }
        this.n=this.k;
        this.k=[]
        this.l=[]
        for(var i=0;i<this.allTvChannel.length;i++)
        {
          if(this.allTvChannel[i].rating==4)
          {
            this.l.push(this.allTvChannel[i])
          }
        }
        this.c=this.l;
        this.l=[]

    }

    }
    else{
      this.rating4=false
      if(this.count>1)
      { this.count--;
        this.q=[]
        for(var i =0;i<this.n.length;i++)
        {
          if(this.n[i].rating!=4)
          {
            this.q.push(this.n[i])
          }
        }
        this.n=this.q;
        this.q=[]
        this.m=[]
        for(var i =0;i<this.c.length;i++)
        {
          if(this.c[i].rating!=4)
          {
            this.m.push(this.c[i])
          }
        }
        this.c=this.m;
        this.m=[]
      }
      else
      { this.count--;
        if(this.showLang==false){
          this.n=this.allNewsPaper;
          this.c=this.allTvChannel}
          else{
            this.n=[]
            this.c=[]
          }
      }
    }

  }
  checkRating5(item: any) {

    if (item.target.checked == true){
      this.rating5=true
      if(this.count>0){
        this.count++;
        
      this.k=this.n
      this.l=this.c
      for(var i=0;i<this.allNewsPaper.length;i++)
      {
        if(this.allNewsPaper[i].rating==5)
        {
          this.k.push(this.allNewsPaper[i])
        }
      }
      this.n=this.k;
      this.k=[]
      for(var i=0;i<this.allTvChannel.length;i++)
      {
        if(this.allTvChannel[i].rating==5)
        {
          this.l.push(this.allTvChannel[i])
        }
      }
      this.c=this.l;
      this.l=[]

    }
    else
    {
        this.count++
        this.k=[]
        for(var i=0;i<this.allNewsPaper.length;i++)
        {
          if(this.allNewsPaper[i].rating==5)
          {
            this.k.push(this.allNewsPaper[i])
          }
        }
        this.n=this.k;
        this.k=[]
        this.l=[]
        for(var i=0;i<this.allTvChannel.length;i++)
        {
          if(this.allTvChannel[i].rating==5)
          {
            this.l.push(this.allTvChannel[i])
          }
        }
        this.c=this.l;
        this.l=[]

    }

    }
    else{
      this.rating5=false
      if(this.count>1)
      { this.count--;
        this.q=[]
        for(var i =0;i<this.n.length;i++)
        {
          if(this.n[i].rating!=5)
          {
            this.q.push(this.n[i])
          }
        }
        this.n=this.q;
        this.q=[]
        this.m=[]
        for(var i =0;i<this.c.length;i++)
        {
          if(this.c[i].rating!=5)
          {
            this.m.push(this.c[i])
          }
        }
        this.c=this.m;
        this.m=[]
      }
      else
      { this.count--;
        if(this.showLang==false){
        this.n=this.allNewsPaper;
        this.c=this.allTvChannel}
        else{
          this.n=[]
          this.c=[]
        }
      }
    }


  }

  selectGenre(val: any) {
    if(this.n.length==this.allNewsPaper.length && this.c.length==this.allTvChannel.length)
    { console.log("Hello")
    
      
      this.c=[]
    }
    if (val.target.value != "default") {
      this.genre = val.target.value
      this.value = val
      this.service.searchGenre(val.target.value).subscribe((response) => {
        this.genreChannel = response;
        console.log(response)
        if (response[0] != null) {

          this.showGenre = true
          this.showGenreRating = true
          
        }


      })
    }
    else {

      this.showGenre = false
      if(this.rating5==false && this.rating4==false && this.rating3==false && this.rating2==false && this.rating1==false){
   
        this.c=this.allTvChannel
  
      }
    }
  }

  sorting(status: any) {
    console.log(this.n)
    if (status.target.checked == true) {
      console.log(this.n)
      this.channelBeforeSort=this.c
      this.newsBeforeSort=this.n
      console.log(this.newsBeforeSort)
      let e : Newspaper[] = this.n
      let x: TvChannel[]=this.c
      this.n=e.sort((a, b) => (a.userName.toLowerCase() < b.userName.toLowerCase() ? -1 : 1));
      this.c=x.sort((a, b) => (a.userName.toLowerCase() < b.userName.toLowerCase() ? -1 : 1));
      this.langChannelFilter.sort((a, b) => (a.userName.toLowerCase() < b.userName.toLowerCase() ? -1 : 1))
      this.langNewspaperFilter.sort((a, b) => (a.userName.toLowerCase() < b.userName.toLowerCase() ? -1 : 1))
     
    }
    else {

      this.n=this.n.sort((a, b) => (a.rating > b.rating ? -1 : 1))
      this.c=this.c.sort((a, b) => (a.rating > b.rating ? -1 : 1))
      this.langNewspaperFilter.sort((a, b) => (a.rating > b.rating ? -1 : 1))
      this.langChannelFilter.sort((a, b) => (a.rating > b.rating ? -1 : 1))
      console.log(this.n)
    
  }
 

}

selectLanguage(val: any) {
  
  console.log(this.beforeChannelLangFilter)
  if(this.n.length==this.allNewsPaper.length && this.c.length==this.allTvChannel.length)
  { console.log("Hello")
  
    this.n=[]
    this.c=[]
  }
  if (val.target.value != "default") {
    this.language = val.target.value
    this.value = val
    this.showLang=true
  
    this.langChannelFilter=[]
    this.langNewspaperFilter=[]
    for(var i =0;i<this.allNewsPaper.length;i++)
    {
      if(this.allNewsPaper[i].language==this.language)
      {
          this.langNewspaperFilter.push(this.allNewsPaper[i])
          this.langNewspaper=this.langNewspaperFilter

      }
    }
    for(var i =0;i<this.allTvChannel.length;i++) 
    {
      if(this.allTvChannel[i].language==this.language)
      {
          this.langChannelFilter.push(this.allTvChannel[i])
          this.langChannel=this.langChannelFilter
      }
    }

    
  }
  else {
    this.showLang = false
    if(this.rating5==false && this.rating4==false && this.rating3==false && this.rating2==false && this.rating1==false){
      console.log("Hello")
      this.n=this.allNewsPaper
      this.c=this.allTvChannel

    }

  }
}

BookChannel(object:any)
{   
  localStorage.setItem("TvChannelId",object.tvChannelId)
  localStorage.setItem("TvChannelCost",object.cost)
  localStorage.setItem("TvChannelName",object.userName)
  localStorage.setItem("transactionStatus","true")
  this.router.navigate(['/customer/booktelevisionchannel'])
    
}
BookNewsPaper(object:any)
{
  localStorage.setItem("NewspaperId",object.newsPaperId)
  localStorage.setItem("NewspaperCost",object.cost)
  localStorage.setItem("NewsPaperName",object.userName)
  localStorage.setItem("transactionStatus","true")
  this.router.navigate(['/customer/booknewspaper'])

}

}

