import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { BookForTelevisionChannelComponent } from './book-for-television-channel.component';

describe('BookForTelevisionChannelComponent', () => {
  let component: BookForTelevisionChannelComponent;
  let fixture: ComponentFixture<BookForTelevisionChannelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes(
        [{path: 'home', redirectTo: ''},{path: 'customer/bookadvertisement', redirectTo: ''}]
      ),ReactiveFormsModule ],
      declarations: [ BookForTelevisionChannelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookForTelevisionChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('form should be valid', () => {

    component.BookForm.get("duration")?.setValue("10")
    component.BookForm.get("days")?.setValue("10")
    component.BookForm.get("cost")?.setValue("10")
    component.BookForm.get("date")?.setValue("30-05-2021")
    expect(component.BookForm.valid).toBeTruthy();

})
it('form should be invalid ', () => {

  component.BookForm.get("duration")?.setValue("")
  component.BookForm.get("page")?.setValue("")
  component.BookForm.get("days")?.setValue("")
  component.BookForm.get("cost")?.setValue("")
  expect(component.BookForm.valid).toBeFalsy();

})
it('should book after giving values', () => {
  component.BookForm.get("duration")?.setValue("10")
  component.BookForm.get("days")?.setValue("10")
  component.BookForm.get("cost")?.setValue("10")
  component.BookForm.get("date")?.setValue("30-05-2021")
  expect("10").toBe(component.BookForm.get('duration')?.value)
  expect("10").toBe(component.BookForm.get('days')?.value)
  expect("10").toBe(component.BookForm.get('cost')?.value)
  expect("30-05-2021").toBe(component.BookForm.get('date')?.value)

});
});
