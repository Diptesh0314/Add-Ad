import { CustomerServiceService } from 'src/app/customer/services/customer-service.service';
import { LoginService } from './../../../core/services/login-service.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-book-for-television-channel',
  templateUrl: './book-for-television-channel.component.html',
  styleUrls: ['./book-for-television-channel.component.css']
})
export class BookForTelevisionChannelComponent implements OnInit {
  maxDate: string;

  constructor(public loginService: LoginService, public service: CustomerServiceService,public router: Router) 
  {
    this.date  = new Date()
    let month = String(this.date.getMonth() + 1).padStart(2, '0'); 
    let day = String(this.date.getDate()+2).padStart(2, '0'); 
    let year = this.date.getFullYear(); 
    let yearMax = this.date.getFullYear()+1;
    this.outDate = year +'-'+month +'-'+day 
    this.maxDate=yearMax+'-'+month+'-'+day
  }

  BookForm = new FormGroup({
    cost: new FormControl(),
    days: new FormControl('', [Validators.required,Validators.min(1),Validators.max(24)]),
    duration: new FormControl('',[Validators.required,Validators.min(5),Validators.max(60)]),
    date: new FormControl('',[Validators.required]),
    })

  id:any
  name:any
  cost:any
  date:Date
  outDate:string
  TvChannelName:any

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    if(!(localStorage.getItem("transactionStatus"))){
      this.router.navigate(["/customer/bookadvertisement"])
    }
    this.TvChannelName=localStorage.getItem("TvChannelName")
    this.cost=localStorage.getItem("TvChannelCost")

  }
  Book()
  {
    this.service.transaction.newsPaperId = 0;
    this.service.transaction.adDurationInPaper=this.BookForm.controls.duration.value
    this.service.transaction.isApproved=0
    this.service.transaction.cost=Number(localStorage.getItem("TvChannelCost"))  
    this.service.transaction.tvChannelId=Number(localStorage.getItem("TvChannelId")) 
    this.service.transaction.numberOfDays =this.BookForm.controls.days.value;
    this.service.transaction.serviceDate= this.BookForm.controls.date.value;
    this.service.transaction.transactionDate = new Date();
    this.service.transaction.companyName = this.TvChannelName;
    
    this.name=localStorage.getItem("name")
    
    this.service.GetUserId(this.name).subscribe((response)=>{
      this.id=response
      this.service.transaction.customerUserId=this.id;    
    })

    this.router.navigate(["/transaction/order"]);
  }

}
