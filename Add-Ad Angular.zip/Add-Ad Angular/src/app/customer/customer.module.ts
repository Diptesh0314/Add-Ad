import { HeaderComponent } from './../shared/components/header/header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookAdvertisementComponent } from './components/book-advertisement/book-advertisement.component';
import { BookForNewspaperComponent } from './components/book-for-newspaper/book-for-newspaper.component';
import { BookForTelevisionChannelComponent } from './components/book-for-television-channel/book-for-television-channel.component';
import { CustomerRoutingModule } from './customer-routing.module';
//import { HttpClientModule } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import {SharedModule} from '../shared/shared.module';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from '../core/services/login-service.service';



@NgModule({
  declarations: [
    BookAdvertisementComponent,
    BookForNewspaperComponent,
    BookForTelevisionChannelComponent,
    UpdateProfileComponent,
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    //HttpClientModule
    HttpClientModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ],
})
export class CustomerModule { }
