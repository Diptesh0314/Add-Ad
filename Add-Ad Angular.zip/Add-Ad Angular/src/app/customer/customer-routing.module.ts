import { TransactionHistoryComponent } from './../transaction/components/transaction-history/transaction-history.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule , Routes } from '@angular/router';

import { BookAdvertisementComponent } from './components/book-advertisement/book-advertisement.component';
import { BookForNewspaperComponent } from './components/book-for-newspaper/book-for-newspaper.component';
import { BookForTelevisionChannelComponent } from './components/book-for-television-channel/book-for-television-channel.component';
import { AuthGuard } from '../authGuard/servies/auth-guard.service';
import { RoleGuardService } from '../authGuard/servies/role-guard.service';

const routes : Routes = [
  {
    path : 'bookadvertisement' , 
    component : BookAdvertisementComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    }
  },
  {
    path : 'transaction',
    component : TransactionHistoryComponent,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    }

  },
  {
    path : 'booknewspaper', 
    component : BookForNewspaperComponent ,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    }
  },
  {
    path : 'booktelevisionchannel', 
    component : BookForTelevisionChannelComponent,
    canActivate: [RoleGuardService],
    data: { 
      expectedRole: 1
    }
  },
  {
    path : 'updateprofile', 
    component : UpdateProfileComponent, canActivate:[AuthGuard]
  }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class CustomerRoutingModule { }
