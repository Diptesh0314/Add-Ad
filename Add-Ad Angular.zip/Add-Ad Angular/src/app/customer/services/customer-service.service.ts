import { Transaction } from '../../models/transaction.model';
import { Newspaper } from './../model/newspaper.model';
import { TvChannel } from './../model/tv-channel.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {baseUrl} from '../../../environments/environment';
import { Customer } from '../../models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
  isLogin: boolean
  name: string
  email: string
  transaction:Transaction = new Transaction()
  channel!:TvChannel[]
  newspaper!:Newspaper[]
  constructor(public http:HttpClient) { }

  channelList(){
    return this.http.get<TvChannel[]>(baseUrl + '/TvChannel')
 
  }
  getName(){
    return this.name;
  }
  setName(name: string){
    this.name=name
  }
  newspaperList(){
    return this.http.get<Newspaper[]>(baseUrl + '/Newspaper')
    
  }
  searchTvChannel(value: string) {
    return this.http.get<TvChannel[]>(baseUrl + '/TvChannel/'+value);
    
  }
  searchNewsPaper(value: string) {
    return this.http.get<TvChannel[]>(baseUrl + '/Newspaper/'+value)
    
  }
  searchGenre(value: string) {
    return this.http.get<Newspaper[]>(baseUrl + '/TvChannel/SearchGenre/'+value)
    
  }
  searchGenreWithRating(value: string, value1:number) {
    return this.http.get<TvChannel[]>(baseUrl + '/TvChannel/SearchGenre/'+value + '/' + value1)
    
  }
  searchTvChannelRating(arg0: number) {
    return this.http.get<TvChannel[]>(baseUrl + '/TvChannel/SearchRating/'+arg0);
  }
  searchNewspaperRating(arg0: number) {
    return this.http.get<Newspaper[]>(baseUrl + '/Newspaper/SearchRating/'+arg0)
    
  }
  updateCustomer(customer:Customer){
    return this.http.post<Number>(baseUrl+"/CustomerUser/update",customer);
}
GetUserId(name:string)
{
  return this.http.get<number>(baseUrl+"/Transaction/GetId/"+name)
}

}
