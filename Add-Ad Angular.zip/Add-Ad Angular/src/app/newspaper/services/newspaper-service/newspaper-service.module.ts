import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Transaction } from 'src/app/models/transaction.model';
import { baseUrl } from '../../../../environments/environment';
import { Email } from 'src/app/models/email.model';


@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class NewspaperServiceModule {
  
  
  email?:string;
  constructor(private _http:HttpClient){}
  approveAndReject(transaction:Transaction){
    console.log(baseUrl);
    return this._http.post<number>(baseUrl+"/NewspaperApprovinglAndBlocking/Approve",transaction);
    
  }
  getTransactions(){
		return this._http.get<Transaction[]>(baseUrl+"/NewspaperApprovinglAndBlocking/GetPendingNewspapers/"+this.email);	
	}
  sendApproval(email:Email)
  {
    return this._http.post(baseUrl+'/Email/SendUpdate',email);	

  }
  sendBlocked(email:Email)
  {
    return this._http.post(baseUrl+'/Email/SendBlocked',email);	

  }

  // getEmailOfNewspaper(transaction: Transaction) {
  //   return this._http.post<Email>(baseUrl+"/Newspaper/GetEmailNewspaper",transaction);
  // } 
  // sendApproveAdvertisementEmailNewspaper(email: Email) {
  //   return this._http.post(baseUrl+"/NewspaperApprovinglAndBlocking/GetEmailOfNewspaper",email);
  // }
  getUserEmail(customerUserId: Number) {
    return this._http.get(baseUrl+'/TvChannel/getEmail/'+customerUserId, {responseType: 'text'})
  }

  sendMail(userEmail: string, status : number) {
    let email : Email = new Email
    email.email = userEmail
    
    if(status === 1){
      return this._http.post(baseUrl+"/Email/SendTransactionNewspaperApproval",email)
    }
    else if(status === -1){
      return this._http.post(baseUrl+"/Email/SendTransactionRejection",email)
    }
    return null;
  }
}
