import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NewspaperCost } from 'src/app/models/newspaper-cost.model';
import { Newspaper } from 'src/app/models/newspaper.model';
import { baseUrl } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NewspaperService {

  newspaperCost: NewspaperCost=new NewspaperCost();
  newspaper:Newspaper=new Newspaper();
  constructor(private http:HttpClient) { }
  valcost?:Number;
 
  EditChannelCost(news: NewspaperCost){
      return this.http.put(baseUrl+'/NewspaperApprovinglAndBlocking/UpdateChannelPrice',news);
    }
    GetEmail(email:string){
      return this.http.get<Newspaper>(baseUrl+'/NewspaperApprovinglAndBlocking/getByEmail/'+email);
    }
}
