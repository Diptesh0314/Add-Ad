import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { DashboardComponent } from './components/newspaperdashboard/dashboard.component';
import { SetPriceComponent } from './components/set-price/set-price.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { NewspaperRoutingModule } from './newspaper-routing.module';
import { SharedModule } from '../shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { NewspaperServiceModule } from './services/newspaper-service/newspaper-service.module';
import {NgxPaginationModule} from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    DashboardComponent,
    SetPriceComponent,
    PendingConfirmationComponent
  ],
  imports: [
    CommonModule,
    NewspaperRoutingModule,
    SharedModule,
    HttpClientModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[NewspaperServiceModule]
})
export class NewspaperModule { }
