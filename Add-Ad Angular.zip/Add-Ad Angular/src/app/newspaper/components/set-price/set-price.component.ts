import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NewspaperCost } from 'src/app/models/newspaper-cost.model';
import { Newspaper } from 'src/app/models/newspaper.model';
import { MustMatchVal } from 'src/app/shared/validators/must-match-val.validator';
import { NewspaperService } from '../../services/newspaper.service';

@Component({
  selector: 'app-set-price',
  templateUrl: './set-price.component.html',
  styleUrls: ['./set-price.component.css']
})
export class SetPriceComponent implements OnInit {
  email:string;
  name:string;
  cost?:Number;
  public value:string;
  newspaper:Newspaper=new Newspaper();
  updatePriceForm!:FormGroup;
  constructor(private ad: FormBuilder,public service:NewspaperService,public router: Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    this.email=localStorage.getItem("email")!;
    this.name=localStorage.getItem("name")!;
     this.value=this.email;
     console.log(this.value);
     console.log(this.cost);

     this.service.GetEmail(this.email).subscribe(
      (newspaper:Newspaper)=>this.setCost(newspaper),
      (err:any)=>console.log(err)
    );

     this.updatePriceForm=this.ad.group({
       
      NewspaperName:[this.value],
       PreviousCost:[''],
       Cost:['',[Validators.required,Validators.min(1)]]
     
   }, {
     validator: MustMatchVal('PreviousCost', 'Cost')
 })
  }
  setCost(newspaperTemp:Newspaper){
    //console.log(tvChannelTemp.cost);
    this.cost=newspaperTemp.cost!;
  }
  updateChannelPrice(){
    this.service.newspaperCost.cost=this.updatePriceForm.controls.Cost.value;
    this.service.newspaperCost.email=this.email;
    this.editCost(this.service.newspaperCost);
  }
  editCost(newspaperCost:NewspaperCost){
    this.service.EditChannelCost(newspaperCost).subscribe(
      res=>{
        this.toastr.success("Updated the cost Successfully");
        this.router.navigate(['/newspaper/dashboard']);
        
      },
      err=>{console.log(err);}
    );
  }

}
