import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Console } from 'node:console';
import { LoginService } from 'src/app/core/services/login-service.service';
import { Customer } from 'src/app/models/customer.model';
import { Email } from 'src/app/models/email.model';
import { LoginModel } from 'src/app/models/loginModel';
import { Transaction } from 'src/app/models/transaction.model';
import { NewspaperServiceModule } from '../../services/newspaper-service/newspaper-service.module';

@Component({
  selector: 'app-pending-confirmation',
  templateUrl: './pending-confirmation.component.html',
  styleUrls: ['./pending-confirmation.component.css']
})
export class PendingConfirmationComponent implements OnInit {

  transactions:Transaction[]
  serialNumber:number=0;
  p: number = 1;
  customer:Customer=new Customer();
  userEmail: string;
  transactionStatus: number;
  constructor(private _service:NewspaperServiceModule,private loginService:LoginService, public router: Router) { }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    //this.serialNumber=-7;
    var email1=localStorage.getItem('email');
    console.log(email1);
    this._service.email=email1?.toString();
    console.log(this._service.email)
    
    this._service.getTransactions().subscribe(response => this.transactions = response);
  }
  // approveAndReject(transaction:Transaction,isApproved:Number){
  //   //this.serialNumber=-21;
  //   transaction.isApproved =isApproved;
  //   transaction.numberOfDays=0;
  //   transaction.pageNumber=0;
  //   transaction.adDurationInPaper=0;
  //   this._service.approveAndReject(transaction).subscribe(res=>{
  //     this._service.getTransactions().subscribe(response => this.transactions = response);
  //     console.log(this.transactions);
      
  //     this._service.getUserEmail(transaction.customerUserId).subscribe(r => this.userEmail = JSON.stringify(r));
  //     this._service.approveAndReject(transaction).subscribe(r => {
  //       this.transactionStatus = r;
  //       this._service.sendMail(this.userEmail,parseInt(this.transactionStatus))?.subscribe()
        
  //     });
    

  //   })
  // }
  approveAndReject(transaction:Transaction,isApproved:Number){
      transaction.isApproved =isApproved;
    transaction.numberOfDays=0;
    transaction.pageNumber=0;
    transaction.adDurationInPaper=0;

    this._service.getTransactions().subscribe(response => this.transactions = response);
    this._service.getUserEmail(transaction.customerUserId).subscribe(r => this.userEmail = JSON.stringify(r));
    this._service.approveAndReject(transaction).subscribe(r => {
      this._service.getTransactions().subscribe(response => this.transactions = response);
      this.transactionStatus = r;
      this._service.sendMail(this.userEmail,this.transactionStatus)?.subscribe()
      
      
    });
  }
  serialNumberIncrement(){
    this.serialNumber=this.serialNumber+1;
    return this.serialNumber;
  }

}
