import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule , Routes } from '@angular/router';
import { DashboardComponent } from './components/newspaperdashboard/dashboard.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { SetPriceComponent } from './components/set-price/set-price.component';
import { RoleGuardService } from '../authGuard/servies/role-guard.service';

const routes : Routes = [
  {
    path: 'dashboard' , component: DashboardComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 2
    } 
  },
  {
    path: 'pendingconfirmation' , component: PendingConfirmationComponent , canActivate: [RoleGuardService],
    data: { 
      expectedRole: 2
    } 
  },
  {
    path: 'setprice' , component: SetPriceComponent , canActivate: [RoleGuardService],
    data: { 
      expectedRole: 2
    } 
  },
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class NewspaperRoutingModule { }
