import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Routes } from '@angular/router';
import { LoginComponent } from '../core/components/login-page/login.component';
import { ForgotPasswordComponent } from '../core/components/forgot-password/forgot-password.component';
import { SignupPageComponent } from './components/signup-page/signup-page.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';



const routes : Routes = [
  {
    path: 'login' , component : LoginComponent
  },
  {
    path: 'forgotpassword' , component : ForgotPasswordComponent
  },
  {
    path:'signup',component : SignupPageComponent
  },
  {
    path: 'resetpassword' , component : ResetPasswordComponent
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class CoreRoutingModule { }
