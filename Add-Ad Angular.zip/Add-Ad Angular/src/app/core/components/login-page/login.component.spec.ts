import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { features } from 'node:process';
import { Customer } from 'src/app/models/customer.model';
import { LoginModel } from 'src/app/models/loginModel';
import { LoginService } from '../../services/login-service.service';

import { LoginComponent } from './login.component';
import { By } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { exception } from 'node:console';
import { ReactiveFormsModule } from '@angular/forms';
import { from } from 'rxjs';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, RouterModule.forRoot([]), ReactiveFormsModule ],
      declarations: [ LoginComponent ],
      providers: [ LoginService ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

  });

  it('should be valid form', () => {
    component.form.get("email")?.setValue("bhimeshp14@gmail.com")
    component.form.get("password")?.setValue("123")

    expect(component.form.valid).toBeTruthy()
  });

  it('should be invalid form', () => {
    component.form.get("email")?.setValue("")
    component.form.get("password")?.setValue("")
    
    expect(component.form.valid).toBeFalsy()
  });

  it('should be invalid email if starts with number and special character',() => {
    component.form.get("email")?.setValue("1bhim@gmail.com")

    expect(component.form.get("email")?.errors?.validator).toBeTruthy()

    component.form.get("email")?.setValue("@bhim@gmail.com")

    expect(component.form.get("email")?.errors?.validator).toBeTruthy()
  });

  it('should call login method when clicked on submit button',() => {
    spyOn(component,'login');
    
    let button = fixture.debugElement.query(By.css("form"));
    button.triggerEventHandler('submit',null);
    fixture.detectChanges();
    expect(component.login).toHaveBeenCalled();
  });

  it('should call login method in login service class',() => {
    let user = new Customer();
    user.emailId = "bhimeshp14@gmail.com"
    user.roleId = 1
    user.userName = "bhimesh"

    component.form.get("email")?.setValue("bhimeshp14@gmail.com")
    component.form.get("password")?.setValue("123")

    let service = TestBed.inject(LoginService); 
    spyOn(service,'login').and.returnValue(from([user]));
    spyOn(component,'routing')
    component.login();
    expect(component.customer).toBe(user);
    expect(component.routing).toHaveBeenCalled();

  });
});