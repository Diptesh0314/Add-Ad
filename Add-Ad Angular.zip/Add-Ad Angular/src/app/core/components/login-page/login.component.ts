
import { CustomerServiceService } from './../../../customer/services/customer-service.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup , FormControl , Validators, AbstractControl, ValidationErrors } from '@angular/forms';

import { Router } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';

import { LoginModel } from 'src/app/models/loginModel';
import { LoginService } from '../../services/login-service.service';
import { HeaderServiceService } from 'src/app/shared/service/header-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  constructor(private loginService : LoginService,public headerService:HeaderServiceService,
    private router : Router) { }

  ngOnInit(): void {
    // if(this.loginService.isLoggedIn())
    //   this.loginService.logout()
    if(this.loginService.isLoggedIn())
      this.router.navigate(['/home'])
  }
  
  loginmodel : LoginModel = new LoginModel;

  customer : Customer

  loggedIn: boolean = false;

  errorMessage : string = ""

  form = new FormGroup({
    email: new FormControl('', [Validators.email , Validators.required , this.validator]),
    password: new FormControl('', [Validators.required, Validators.minLength(1), Validators.maxLength(20)])
  })

  get email(){
    return this.form.controls.email
  }
 
  get password(){
    return this.form.controls.password
  }

  validator(control : AbstractControl) : ValidationErrors | null{
    let char = (control.value as string)
    let regexp = new RegExp('[a-zA-Z]')
    if(!regexp.test(char[0]))
      return { validator : true }
      
    return null
  }
  
  login(){
    this.loginmodel.emailid = this.form.controls.email.value
    this.loginmodel.password = this.form.controls.password.value
    this.loginService.login(this.loginmodel).subscribe(response => {
      if(response){
        this.customer = response
        localStorage.setItem("name",this.customer.userName)
        localStorage.setItem("email",this.customer.emailId)
        this.headerService.isLogin=true
      }
      this.routing()
    },error => {
      this.errorMessage = error.error;
      
    })
  }

  routing(){
    if(this.customer.roleId===1){
      console.log("helloooooooo")
      this.router.navigate(['/customer/bookadvertisement'])
    }
    else if(this.customer.roleId===2){
      this.router.navigate(['/newspaper/dashboard'])
    }
    else if(this.customer.roleId===3){
      this.router.navigate(['/channel/dashboard'])
    }
    else if(this.customer.roleId===4){
      this.router.navigate(['/admin/dashboard'])
    }
  }

  testing(){
    this.loginService.testing().subscribe(response => {
      console.log(response)
    })
  }

}
