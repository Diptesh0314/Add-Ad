import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';

import { ResetPasswordComponent } from './reset-password.component';

describe('ResetPasswordComponent', () => {
  let component: ResetPasswordComponent;
  let fixture: ComponentFixture<ResetPasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResetPasswordComponent ],
      imports: [HttpClientModule, RouterModule.forRoot([]), ReactiveFormsModule, FormsModule,ToastrModule.forRoot(),
      FormsModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
  // it('should login after giving credentials', () => {
    

  //   component.resetPasswordForm.get("password")?.setValue("1234")
  //   component.resetPasswordForm.get("confirmPassword")?.setValue("1234")
  //   expect("1234").toBe(component.resetPasswordForm.get('confirmPassword')?.value)
  // });
  
});
