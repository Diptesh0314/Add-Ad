import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl,FormGroup, Validators } from '@angular/forms';
import {ActivatedRoute,Router,ParamMap} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MustMatch } from 'src/app/shared/validators/must-match.validator';
import { ResetService } from '../../services/reset-service.service';
import * as CryptoJS from "crypto-js";
import { Console } from 'node:console';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  public _email: string;
  public _token: string;
  public value: string;
  public decryptedToken: string;
  public resetPasswordForm: FormGroup;
  public showSuccess: boolean;
  public showError: boolean;
  public errorMessage: string;
  constructor(private toastr:ToastrService,private resetService:ResetService,private router: Router,private _route: ActivatedRoute,private ad: FormBuilder) { }
// selectedEmail:number
  ngOnInit(): void {
    this._email = this._route.snapshot.queryParams['value'];
    console.log(this._email);
    this._token = this._route.snapshot.queryParams['token'];
    console.log(this._token);
    this.value=this.decrypt("01234567890123456789012345678901",this._email);
    console.log(this.value);
    this.decryptedToken=this.decrypt("01234567890123456789012345678901",this._token);
    console.log(this.value);
    
    this.resetPasswordForm=this.ad.group({
      password:['',[Validators.required,Validators.minLength(8),Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]],
      confirmPassword:['',[Validators.required]]
  }, {
    validator: MustMatch('password', 'confirmPassword')
})
  }
  updatePassword(){
    
    console.log(this.resetPasswordForm.value);
    this.resetService.customer.emailId=this.value;
    console.log(this._token);
    this.resetService.customer.token=parseInt(this.decryptedToken);
    this.resetService.customer.password=this.resetPasswordForm.controls.password.value;
    this.resetService.updatePassword(this.resetService.customer).subscribe(response => {
      this.router.navigate(['/core/login'])
      this.toastr.success("Your Password reset was successful!");
    },error => {
      this.errorMessage = error.error
      this.toastr.error("Some error occured");
      this.router.navigate(['/core/login'])
    })
       
  }
  
  decrypt(key:any, ciphertextB64:any) {  
                           
    var key:any = CryptoJS.enc.Utf8.parse(key);                             
    var iv = CryptoJS.lib.WordArray.create([0x00, 0x00, 0x00, 0x00]);  
 
    var decrypted = CryptoJS.AES.decrypt(ciphertextB64, key, {iv: iv}); 
  return decrypted.toString(CryptoJS.enc.Utf8);                       
} 

}
