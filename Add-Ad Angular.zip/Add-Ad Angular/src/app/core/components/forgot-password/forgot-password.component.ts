import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ForgotPasswordService } from '../../services/forgot-password.service';
import { ForgotPasswordDto } from '../../_interfaces/resetPassword/forgot-password-dto.model';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  
  public currentPageUrl: string = window.location.href;
  public forgotPasswordForm: FormGroup
  public successMessage: string;
  public errorMessage: string;
  public showSuccess: boolean;
  public showError: boolean;
  constructor(private _authService: ForgotPasswordService,private toastr:ToastrService) { }

  ngOnInit(): void {
    console.log(this.currentPageUrl);
    this.currentPageUrl=this.currentPageUrl.substring(0,this.currentPageUrl.length-14)
    this.currentPageUrl=this.currentPageUrl+'resetpassword';
    console.log(this.currentPageUrl);

    this.forgotPasswordForm = new FormGroup({
      email: new FormControl("", [Validators.required])
    })
  }
  public validateControl = (controlName: string) => {
    return this.forgotPasswordForm.controls[controlName].invalid && this.forgotPasswordForm.controls[controlName].touched
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.forgotPasswordForm.controls[controlName].hasError(errorName)
  }
  public forgotPassword = (forgotPasswordFormValue: any) => {
    
    this.showError = this.showSuccess = false;
    const forgotPass = { ...forgotPasswordFormValue };
    const forgotPassDto: ForgotPasswordDto = {
      email: forgotPass.email,
      clientURI: this.currentPageUrl
    }
    this._authService.forgotPassword('Email/ForgotPassword', forgotPassDto)
    .subscribe(_ => {
      this.showSuccess = true;
      this.successMessage = 'The link has been sent, please check your email to reset your password.'
      this.toastr.success("Reset password link sent to your Email!");
    },
    err => {
      this.showError = true;
      this.errorMessage = "Please enter valid Email address";
      this.toastr.error("Email not registered");
    })
  }

}
