import { ReactiveFormsModule, FormControl, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';

import { SignupPageComponent } from './signup-page.component';
import { ToastrModule } from 'ngx-toastr';

describe('SignupPageComponent', () => {
  let component: SignupPageComponent;
  let fixture: ComponentFixture<SignupPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule, RouterModule.forRoot([]),ReactiveFormsModule, FormsModule,ToastrModule.forRoot()],
      declarations: [ SignupPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should login after giving credentials', () => {


    component.signupForm.get("email")?.setValue("diptesh308@gmail.com")
    component.signupForm.get("password")?.setValue("123")
    component.signupForm.get("confirmPassword")?.setValue("123")
    component.signupForm.get("role")?.setValue("1")
    component.signupForm.get("rating")?.setValue("5")
    component.signupForm.get("genre")?.setValue("musics")
    component.signupForm.get("language")?.setValue("english")



    
    expect("123").toBe(component.signupForm.get('password')?.value)
    expect("1").toBe(component.signupForm.get('role')?.value)
    expect("123").toBe(component.signupForm.get('confirmPassword')?.value)
    expect("musics").toBe(component.signupForm.get('genre')?.value)
    expect("5").toBe(component.signupForm.get('rating')?.value)
    expect("english").toBe(component.signupForm.get('language')?.value)
    expect("diptesh308@gmail.com").toBe(component.signupForm.get('email')?.value)
  });

  it('should call registerCustomer method when button is clicked', () => {

    spyOn(component,'registerCustomer');
    fixture.detectChanges();
    document.getElementById('submit')?.click()
    fixture.detectChanges();
    expect(component.registerCustomer).toHaveBeenCalled();
  
  
  });
  it('should not be valid form', () => {
    component.signupForm.get("email")?.setValue("diptesh308@gmail.com")
    component.signupForm.get("password")?.setValue("123")
    component.signupForm.get("confirmPassword")?.setValue("123")
    component.signupForm.get("role")?.setValue("1")
    component.signupForm.get("rating")?.setValue("5")
    component.signupForm.get("genre")?.setValue("musics")
    component.signupForm.get("language")?.setValue("english")


    expect(component.signupForm.valid).toBeFalsy()
  });

});

