import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { userInfo } from 'os';
import { error } from 'protractor';
import { Observable } from 'rxjs';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { Customer } from 'src/app/models/customer.model';
import { SignupPageService } from '../../services/signup-page.service';
import {MustMatch} from '../../../shared/validators/must-match.validator';
import { ToastrService } from 'ngx-toastr';
import { NgbModal,ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-signup-page',
  templateUrl: './signup-page.component.html',
  styleUrls: ['./signup-page.component.css']
})
export class SignupPageComponent implements OnInit {
  

  
  content:any;
  closeResult = '';
  signupForm!:FormGroup;
  roleList: any = ['Customer', 'Newspaper', 'Channel']
  genreList: any = ['Kids', 'News', 'Sports','Music','Movies']
  languageList:any=['English','Bengali','Hindi']
  test?:boolean=true;
  customer:string="Customer";
  newspaper:string="Newspaper";
  channel:string="Channel";
  newCustomerId:Number;
  roleType:Number=1;
  toggleCheck:boolean=false;
  loggedIn:boolean=false;
  currentUser$:Observable<Customer>;
  form: any;
  constructor(private signupService:SignupPageService,private router: Router,private ad: FormBuilder,private toastr:ToastrService,private modalService: NgbModal ) { }
   roleIds:{[rolename:string]:number}={
     "Customer":1,
     "Newspaper":2,
     "Channel":3,
     "":1
   }
   languageSelection:{[languagename:string]:string}={
    "English":"English",
    "Bengali":"Bengali",
    "Hindi":"Hindi",
    "":"English"
  }
  genreSelection:{[genrename:string]:string}={
    'Kids':'Kids',
    'News':'News',
    'Sports':'Sports',
    'Music':'Music',
    'Movies':'Movies',
    '':'Kids'
  }
 
  

  ngOnInit(): void {
   // this.signupService.getCustomerList();
this.signupForm=this.ad.group({
        userName:['',[Validators.required,Validators.minLength(1),Validators.pattern("^[A-Za-z]{1,10}[ .]{0,1}[A-Za-z\s]{0,9}$")]],
        email:['',[Validators.required,Validators.pattern("[^0-9!@#$%^&*()][a-zA-Z._%+a-z0-9]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
        password:['',[Validators.required,Validators.minLength(8),Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]],
        confirmPassword:['',[Validators.required]],
        role:[''],
        genre:[''],
        language:[''],
        rating:['',[Validators.min(1),Validators.max(5)]],
        circulation:['',[Validators.min(50),Validators.max(100000)]],
        acceptTerms: [false, Validators.required]
      
      
    }, {
      validator: MustMatch('password', 'confirmPassword')
  })

  
  }
  
  
  toggleTextBox(){
    this.toggleCheck=!this.toggleCheck
  }
  
  registerCustomer(){
    
    this.signupService.customer.userName=this.signupForm.controls.userName.value;
    this.signupService.customer.emailId=this.signupForm.controls.email.value;
    this.signupService.customer.password=this.signupForm.controls.password.value;
    this.signupService.customer.roleId=this.roleIds[this.signupForm.controls.role.value];
    this.signupService.registerCustomer(this.signupService.customer).subscribe((custId:Number)=>{
      this.newCustomerId=custId;
      this.signupService.email.email=this.signupForm.controls.email.value;
      this.signupService.sendMail(this.signupService.email).subscribe(res=>{},
        error=>{console.log(error);}
        );
        this.toastr.success("Sign up succesful");
      if(this.signupForm.controls.role.value==="Newspaper"||this.signupForm.controls.role.value==="Channel"){
        this.OrganisationType();
      }
      else{
        this.router.navigate(['/core/login'])
      }
      

    },error=>{
      this.toastr.error("user already exists, please login");
    })
       
  }
   OrganisationType(){
    if(this.signupForm.controls.role.value==="Newspaper")
    {
      this.registerNewspaper();    
    }
    if(this.signupForm.controls.role.value==="Channel"){
      this.registerChannel(); 
    }
   }
  registerNewspaper(){
    
    this.signupService.newspaper.customerUserId=this.newCustomerId;
    this.signupService.newspaper.language=this.languageSelection[this.signupForm.controls.language.value];
    this.signupService.newspaper.rating=this.signupForm.controls.circulation.value;
    console.log(this.signupService.newspaper);
    this.signupService.registerNewspaper(this.signupService.newspaper).subscribe(
      res=>{
        this.router.navigate(['/core/login']);
      },
      err=>{console.log(err);}
    );
  }


  registerChannel(){
    this.signupService.tvChannel.customerUserId=this.newCustomerId;
    this.signupService.tvChannel.genre=this.genreSelection[this.signupForm.controls.genre.value];
    this.signupService.tvChannel.language=this.languageSelection[this.signupForm.controls.language.value];
    this.signupService.tvChannel.rating=this.signupForm.controls.rating.value;
    this.signupService.registerChannel(this.signupService.tvChannel).subscribe(
      res=>{
        this.router.navigate(['/core/login']);
      },
      err=>{console.log(err);}
    );



  }



 

  
  


}
