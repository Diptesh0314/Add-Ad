import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreRoutingModule } from './core-routing.module';
import { LoginComponent } from './components/login-page/login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { SignupPageComponent } from './components/signup-page/signup-page.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [
    LoginComponent, 
    ForgotPasswordComponent,
    SignupPageComponent,
    ResetPasswordComponent
  ],
  imports: [
    CommonModule,
    CoreRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    HttpClientModule,
    NgbModule
    
  ],
  exports :[
    LoginComponent,
    SignupPageComponent
  ]
})
export class CoreModule{

}
