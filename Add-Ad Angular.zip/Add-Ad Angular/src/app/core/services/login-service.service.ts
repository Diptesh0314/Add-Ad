import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from  'rxjs/operators';
import { JwtHelperService  } from '@auth0/angular-jwt';

import { LoginModel } from '../../models/loginModel';
import { Customer } from '../../models/customer.model';
import { Router } from '@angular/router';
import { baseUrl } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  customer : Customer = new Customer


  constructor(private http : HttpClient,private router : Router) { 
    
  }
  name: string
  email: string
  isLogin: boolean

  login(model : LoginModel){
    //if(this.isLoggedIn())
      //this.logout()
    return this.http.post<any>(baseUrl+"/CustomerUser/login",model).pipe(map(
      ( response => {
        let result = response
        if(result){

          localStorage.setItem("token",response.token)
          return this.customerDetails()
        }
        return null
      }
      )));
  }

  logout(){
    //location.reload()
    this.isLogin=false
    localStorage.removeItem("token")
    if(!localStorage.getItem("token")){
      this.router.navigate(["/core/login"])
    }
  }

  isLoggedIn(){
    let token = localStorage.getItem("token");
    if(!token)
      return false
    return true
  }

  customerDetails(){
    let token = localStorage.getItem("token");
    if(!token)
      return 
    let decodedToken = new JwtHelperService().decodeToken(token);
    this.customer.userName = decodedToken.unique_name;
    this.customer.emailId = decodedToken.email;
    this.customer.roleId = Number(decodedToken.azp); 
    return this.customer
  }

  testing(){
    return this.http.get(baseUrl+"/CustomerUser/testing",{responseType:'text'})
  }


  
}
