import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from 'src/app/models/customer.model';
import {map} from 'rxjs/operators';
import { Observable, ReplaySubject } from 'rxjs';
import {baseUrl} from '../../../environments/environment';
import { Newspaper } from 'src/app/customer/model/newspaper.model';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Email } from 'src/app/models/email.model';

@Injectable({
  providedIn: 'root'
})
export class SignupPageService {
  email:Email=new Email();
  customer:Customer=new Customer();
  newspaper:Newspaper=new Newspaper();
  tvChannel:TvChannel=new TvChannel();
  private currentUserSource=new ReplaySubject<Customer>(1);
  currentUser$=this.currentUserSource.asObservable();
  allCustomersList:Customer[];
  constructor(private http:HttpClient) { }
  
  registerCustomer(customer:Customer){
      return this.http.post<Number>(baseUrl+"/CustomerUser",customer);
  }
 
  registerNewspaper(newspaper:Newspaper){
   return this.http.post(baseUrl+'/Newspaper',newspaper);
  }

  registerChannel(tvChannel:TvChannel){
    return this.http.post(baseUrl+'/TvChannel',tvChannel);
   }

   getCustomerList(){
    this.http.get(baseUrl)
    .toPromise().then(res=>this.allCustomersList=res as Customer[]);
  }


  setCurrentUser(customer:Customer){
    this.currentUserSource.next(customer);
  }
  logout(){
    localStorage.removeItem('customerVal');
    this.currentUserSource.next(null!);
  }
  sendMail(email:Email){
    console.log(email);
    console.log("hi");
    return this.http.post(baseUrl+'/Email/SendMail',email);
  }


}
