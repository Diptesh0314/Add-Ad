import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from 'src/app/models/customer.model';
import { baseUrl } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResetService {

  customer:Customer=new Customer();
  constructor(private http:HttpClient) { }
  updatePassword(customer:Customer){
    return this.http.post<Number>(baseUrl+"/ResetPassword",customer);
}
}
