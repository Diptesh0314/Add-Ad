import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';

import { SignupPageService } from './signup-page.service';

describe('SignupPageService', () => {
  let service: SignupPageService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientModule, RouterModule.forRoot([])]
    });
    service = TestBed.inject(SignupPageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
