import { Injectable } from '@angular/core';
import { baseUrl, environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EnvironmentUrlService {
  public urlAddress: string = baseUrl;

  constructor() { }
}
