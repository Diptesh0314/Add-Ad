export interface ForgotPassword {
    email: string;
    clientURI: string;
}