import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule , Routes } from '@angular/router';
import { DashboardComponent } from './components/televisiondashboard/dashboard.component';
import { SetpriceComponent } from './components/setprice/setprice.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { RoleGuardService } from '../authGuard/servies/role-guard.service';

const routes : Routes = [
  {
    path: 'dashboard', component : DashboardComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 3
    } 
  },
  {
    path: 'setprice', component : SetpriceComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 3
    } 
  },
  {
    path: 'pendingconfirmation', component : PendingConfirmationComponent, canActivate: [RoleGuardService],
    data: { 
      expectedRole: 3
    } 
  },
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class TelevisionChannelRoutingModule { }
