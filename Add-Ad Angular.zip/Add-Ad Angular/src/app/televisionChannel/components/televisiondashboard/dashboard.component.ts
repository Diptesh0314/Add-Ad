import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/core/services/login-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(public loginService:LoginService,private router:Router) { }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    // console.log(this.loginService.customer.roleId);
    // if(this.loginService.customer.roleId==3){
    //   location.reload();
    // }
    // else if(this.loginService.customer.roleId!=3){
    //   this.router.navigate(['/home']);
    // }
    
  }

}
