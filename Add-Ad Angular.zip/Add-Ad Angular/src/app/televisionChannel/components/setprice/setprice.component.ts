import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { TelevisionCost } from 'src/app/models/television-cost.model';
import { MustMatchVal } from 'src/app/shared/validators/must-match-val.validator';
import { TelevisionService } from '../../services/television.service';

@Component({
  selector: 'app-setprice',
  templateUrl: './setprice.component.html',
  styleUrls: ['./setprice.component.css']
})
export class SetpriceComponent implements OnInit {
  email:string;
  name:string;
  cost?:Number;
  tvChannel:TvChannel=new TvChannel();
  updatePriceForm!:FormGroup;
  constructor(private ad: FormBuilder,public service:TelevisionService,private router:Router,private toastr:ToastrService) { 
    
  }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
   this.email=localStorage.getItem("email")!;
   this.name=localStorage.getItem("name")!;
    this.service.GetEmail(this.email).subscribe(
      (tvChannelVal:TvChannel)=>this.setCost(tvChannelVal),
      (err:any)=>console.log(err)
    );
    

    this.updatePriceForm=this.ad.group({
      
      ADFrequency:[5],
      PreviousCost:[''],
      Cost:['',[Validators.required,Validators.min(100),Validators.required,Validators.max(500000)]]
    
  }, {
    validator: MustMatchVal('PreviousCost', 'Cost')
})
  }
  setCost(tvChannelTemp:TvChannel){
    //console.log(tvChannelTemp.cost);
    this.cost=tvChannelTemp.cost!;
  }
  updateChannelPrice(){
    this.service.televisionCost.cost=this.updatePriceForm.controls.Cost.value;
    this.service.televisionCost.email=this.email;
    this.editCost(this.service.televisionCost);
  }
  editCost(televisionCost:TelevisionCost){
    this.service.EditChannelCost(televisionCost).subscribe(
      res=>{
        this.toastr.success("Updated Successful");
        this.router.navigate(['/channel/dashboard']);
        
      },
      err=>{console.log(err);}
    );
  }

}
