import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/core/services/login-service.service';

import { Customer } from 'src/app/models/customer.model';
import { Email } from 'src/app/models/email.model';
import { Transaction } from 'src/app/models/transaction.model';
import { TvChannel } from 'src/app/models/tv-channel.model';



import { TelevisionService } from '../../services/television.service';

@Component({
  selector: 'app-pending-confirmation',
  templateUrl: './pending-confirmation.component.html',
  styleUrls: ['./pending-confirmation.component.css']
})
export class PendingConfirmationComponent implements OnInit {

  transactions:Transaction[];
  p: number = 1;

  email? : any
  tvChannel : TvChannel
  id : number
  userEmail : string
  transactionStatus : number
  
  constructor(private _service : TelevisionService, public router:Router) {
    this.email = localStorage.getItem('email')
    this.getTransactions();
  }

  ngOnInit(): void {
    if(!localStorage.getItem("token")){
      this.router.navigate(["/home"])
    
    }
    this._service.getTransactions(this.email).subscribe(response => this.transactions = response);
  }
 
  getTransactions(){
    this._service.getTransactions(this.email).subscribe(response => this.transactions = response);
  }


  approveAndReject(transaction:Transaction,isApproved:Number){
    transaction.isApproved =isApproved;
    transaction.numberOfDays=0;
    transaction.pageNumber=0;
    this._service.getTransactions(this.email).subscribe(response => 
      {this.transactions = response},
      error => console.log(error.error)
      );
    this._service.getUserEmail(transaction.customerUserId).subscribe(r => 
      this.userEmail = JSON.stringify(r),
      error => console.log(error.error)
      );
    this._service.approveAndReject(transaction).subscribe(r => {
      this._service.getTransactions(this.email).subscribe(response => 
        {this.transactions = response},
        error => console.log(error.error)
        );
      this.transactionStatus = r;
      this._service.sendMail(this.userEmail,this.transactionStatus)?.subscribe(
        () => {},
        error => console.log(error.error)
      );
      
    });
  }


}
