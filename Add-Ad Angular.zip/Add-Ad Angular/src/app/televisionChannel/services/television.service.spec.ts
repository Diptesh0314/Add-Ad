import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { TelevisionService } from './television.service';

describe('TelevisionService', () => {
  let service: TelevisionService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,HttpClientModule]
    });
    service = TestBed.inject(TelevisionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
