import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import {baseUrl} from '../../../environments/environment';
import { Observable } from 'rxjs';
import { TelevisionCost } from 'src/app/models/television-cost.model';
import { Transaction } from 'src/app/models/transaction.model';
import { TvChannel } from 'src/app/customer/model/tv-channel.model';
import { Email } from 'src/app/models/email.model';
import { Customer } from 'src/app/models/customer.model';
import { stat } from 'node:fs';


@Injectable({
  providedIn: 'root'
})
export class TelevisionService {
  

  televisionCost: TelevisionCost=new TelevisionCost();
  tvChannel:TvChannel=new TvChannel();


  constructor(private http:HttpClient) {
    
  }
  
  valcost?:Number;

  getUserEmail(customerUserId: Number) {
    return this.http.get(baseUrl+'/TvChannel/getEmail/'+customerUserId, {responseType: 'text'})
  }

  sendMail(userEmail: string, status : number) {
    let email : Email = new Email
    email.email = userEmail
    
    if(status === 1){
      return this.http.post(baseUrl+"/email/SendTransactionApproval",email)
    }
    else if(status === -1){
      return this.http.post(baseUrl+"/email/SendTransactionRejection",email)
    }
    return null;
  }

  GetEmail(email:string){
    return this.http.get<TvChannel>(baseUrl+'/TvChannel/getByEmail/'+email);
  }

  EditChannelCost(television:TelevisionCost){
    return this.http.put(baseUrl+'/TvChannel/UpdateChannelPrice',television);
  }

  approveAndReject(transaction:Transaction){
    
    return this.http.post<number>(baseUrl+"/TvChannel/TransactionStatusConfirmation",transaction);
    
  }

  getTransactions(email?: string){
    return this.http.get<Transaction[]>(baseUrl+"/TvChannel/GetPendingTransactionRequests/"+email);	
  }
}
