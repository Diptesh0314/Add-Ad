import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './components/televisiondashboard/dashboard.component';
import { SetpriceComponent } from './components/setprice/setprice.component';
import { PendingConfirmationComponent } from './components/pending-confirmation/pending-confirmation.component';
import { TelevisionChannelRoutingModule } from './television-channel-routing.module';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    DashboardComponent, 
    SetpriceComponent, 
    PendingConfirmationComponent
  ],
  imports: [
    CommonModule,
    TelevisionChannelRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule
  ]
})
export class TelevisionChannelModule { }
