export class Customer {
        token!:Number;
        userName!:string;
        emailId!:string;
        roleId!:Number;
        password!:string;
}
