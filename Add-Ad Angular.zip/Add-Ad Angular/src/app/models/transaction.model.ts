export class Transaction {
        transactionId!:Number;

        tvChannelId!:Number;
        newsPaperId!:Number;
        customerUserId!:Number;

        transactionDate!:Date;
        serviceDate!:Date;

        cost!:Number;
        isApproved!:Number;

        adSizeInPaper!:Number;
        adDurationInPaper!:Number;
        numberOfDays!:Number;
        pageNumber!:Number;

        companyName!:string;

        userName!:string;
        duration!:Number;         
        newspaperId!:Number;
}
