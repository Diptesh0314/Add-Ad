export class NewspaperCost {
    email:string
     cost:Number;
}
