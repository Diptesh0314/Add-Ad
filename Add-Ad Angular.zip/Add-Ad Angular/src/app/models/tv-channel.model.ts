export class TvChannel {
    tvChannelId:Number;
    customerUserId:Number;
    genre:string;
    language:string;
    isApproved:boolean;
    isBlocked:boolean;
    cost:Number;
    rating:Number;
}
