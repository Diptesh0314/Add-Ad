export class Newspaper {
        newsPaperId:Number;
        customerUserId:Number;
        language:string;
        isApproved:boolean;
        isBlocked:boolean;
        cost:Number;
        rating:Number;
}
