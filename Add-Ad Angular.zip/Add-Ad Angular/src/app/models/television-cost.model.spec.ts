import { TelevisionCost } from './television-cost.model';

describe('TelevisionCost', () => {
  it('should create an instance', () => {
    expect(new TelevisionCost()).toBeTruthy();
  });
});
