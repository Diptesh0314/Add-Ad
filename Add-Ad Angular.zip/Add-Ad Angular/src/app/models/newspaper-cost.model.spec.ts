import { NewspaperCost } from './newspaper-cost.model';

describe('NewspaperCost', () => {
  it('should create an instance', () => {
    expect(new NewspaperCost()).toBeTruthy();
  });
});
