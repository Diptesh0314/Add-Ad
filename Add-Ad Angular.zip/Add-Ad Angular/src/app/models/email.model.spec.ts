import { Email } from './email.model';

describe('Email', () => {
  it('should create an instance', () => {
    expect(new Email()).toBeTruthy();
  });
});
