export class LoginModel {
    emailid!: string;
    password!: string;
}