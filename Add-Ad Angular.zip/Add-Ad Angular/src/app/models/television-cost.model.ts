export class TelevisionCost {
     email:string
     cost:Number;
}
